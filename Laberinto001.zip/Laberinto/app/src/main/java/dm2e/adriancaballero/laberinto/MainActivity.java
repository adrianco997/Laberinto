package dm2e.adriancaballero.laberinto;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

/**
 *
 * @author Adrian Caballeo Orasio
 */
public class MainActivity extends AppCompatActivity {
    private static final int SECONDARY_ACTIVITY_TAG = 1;
    private static final String TAG = "ASSERT";
    String laberinto = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        RadioGroup rg = (RadioGroup) findViewById(R.id.ll1);for (int i = 1, mazeId = getResourceId("m" + i, "raw"); mazeId != 0; i++, mazeId = getResourceId("m" + i, "raw")) { Log.println(Log.ASSERT, TAG, "raw.m" + i + ": " + mazeId);RadioButton rb = new RadioButton(this);rb.setText(getResourceId("laberinto_" + i, "string"));rb.setTag(getResourceId("laberinto_" + i, "string"));rg.setOnClickListener(new View.OnClickListener() {public void onClick(View v) { Log.println(Log.ASSERT, TAG, "onClick raw.m" + v.getTag() + ": " + v.getId());RadioGroup rg = (RadioGroup) findViewById(R.id.ll1);for (int i = 0; i < rg.getChildCount(); i++) { if (rg.getChildAt(i) != v) ((RadioButton) rg.getChildAt(i)).setChecked(false); }if (v.getTag() != null) laberinto = (String) v.getTag();else laberinto = ""; }});rg.addView(rb); }
    }
//    private static int ids = 1;
//    public int findId() { View v = findViewById(ids);while (v != null) v = findViewById(++ids);return ids++; }

    public void onPulsar(View v) {
        String nombre = ((EditText) findViewById(R.id.etNombre)).getText().toString().trim();
        if (nombre.equals("")) muestraMensaje(R.string.nombreInvalido,Toast.LENGTH_SHORT);
        else if (laberinto.equals("")) muestraMensaje(R.string.laberintoInvalido,Toast.LENGTH_SHORT);
        else {
            Intent intent = new Intent(this, SegundaActividad.class);
            intent.putExtra("nombre", nombre);
            intent.putExtra("laberinto", laberinto);
            startActivityForResult(intent, SECONDARY_ACTIVITY_TAG);
        }
    }

    public void selectLaberinto(View v) {
        if (v.getId() == R.id.laberinto1) laberinto = "m1";
        else if (v.getId() == R.id.laberinto2) laberinto = "m2";
        else if (v.getId() == R.id.laberinto3) laberinto = "m3";
        else if (v.getId() == R.id.laberinto4) laberinto = "m4";
        else laberinto = "";
    }
    //protected void muestraMensaje(String txt, int duration) { Toast.makeText(this, txt, duration).show(); }
    protected void muestraMensaje(int id, int duration) { Toast.makeText(this, id, duration).show(); }
    //public int getResourceId(String name, String defType) { return getResources().getIdentifier(name, defType, getPackageName()); }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);/*String respuesta = data.getStringExtra("respuesta");*//*if(resultCode==RESULT_FIRST_USER){}else if(resultCode==RESULT_OK){}else if(resultCode==RESULT_CANCELED){}*/
//        ((RadioButton) findViewById(R.id.laberinto1)).setChecked(false);((RadioButton) findViewById(R.id.laberinto2)).setChecked(false);((RadioButton) findViewById(R.id.laberinto3)).setChecked(false);((RadioButton) findViewById(R.id.laberinto4)).setChecked(false);
        RadioGroup rg = (RadioGroup) findViewById(R.id.ll1);
        int rbId = (rg).getCheckedRadioButtonId();
        ((RadioButton) findViewById(rbId)).setChecked(false);
        onPause();
    }

    @Override
    public void onPause() {
        super.onPause();
        if (Musica.getMp() != null && Musica.getMp().isPlaying()) {
            Musica.onPause();
            Musica.retirar();
        }
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
}