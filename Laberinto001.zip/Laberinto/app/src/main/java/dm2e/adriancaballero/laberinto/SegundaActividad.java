package dm2e.adriancaballero.laberinto;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

/**
 *
 * @author Adrian Caballeo Orasio
 */
public class SegundaActividad extends AppCompatActivity {
    String laberintoType = "error", nombreJugador = "";
    //static final int AUDIO_PATH_RAW1 = R.raw.;
    private Maze maze = null;
    private Point actual = null;
    int moves = 0;
    Point input = null;
    Point output = null;
    TextView tvLaberinto;
    boolean hasGanado = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_actividad);

        tvLaberinto = findViewById(R.id.tvLaberinto);

        nombreJugador = getIntent().getStringExtra("nombre");
        laberintoType = getIntent().getStringExtra("laberinto");

        TextView tv1 = findViewById(R.id.tv1);
        tv1.setText(String.format(getResources().getString(R.string.ordenaLaberinto), nombreJugador));
        TextView tvC = findViewById(R.id.tvContador);
        tvC.setText(String.format(getResources().getString(R.string.movimientos), moves));

        //musica(AUDIO_PATH_RAW1);
        play(getResourceId(laberintoType, "raw"));
    }

    //public void main(int[] args) { if (args.length == 0) { main(new int[]{R.raw.m1});/*main(new int[] { R.raw.m2. });*//*main(new int[] { R.raw.m3. });*//*main(new int[] { R.raw.m4. });*/return; }/*ejsOld(args[0], 0);*/play(args[0]); }
    //public void ejsOld(int mfile, int i) { String texto = "SALIDA ENCONTRADA, longitud del camino con %s y estrategia %s, %s, %s, %s: %d unidades.\n", tipo = "algoritmo recursivo";System.out.println("-->Recursivo:\n");MazeSolver ms = new MazeSolver();int pathlength = ms.recursiveSolver(this, mfile, strat1, true);if (pathlength != -1) { System.out.printf(texto, tipo, strat[i][0], strat[i][1], strat[i][2], strat[i][3], pathlength); } else { System.err.println("SALIDA NO ENCONTRADA."); }ms.runSolver(this, mfile, strat); }
    ///**llama a stackSolver, queueSolver y recursiveSolver con una matriz de movimientos*/public void runSolver(Context contexto, int mfile, Movements[][] strat) { for (Movements[] movements : strat) { if (movements.length != 4) { System.err.println("Numero de movimientos incorrecto.");return; }System.out.printf("ESTRATEGIA %s, %s, %s, %s\n", movements[0], movements[1], movements[2], movements[3]);struct(contexto, "pila", mfile, movements, true, 2);struct(contexto, "cola", mfile, movements, true, 2);struct(contexto, "algoritmo recursivo", mfile, movements, true, 3); } }
    //public void struct(Context contexto, String solver, int mfile, Movements[] strat, boolean compare, int type) { String texto = "SALIDA ENCONTRADA, longitud del camino con %s y estrategia %s, %s, %s, %s: %d unidades.\n";System.out.println(Utils.formatR("Con " + solver + ":", '-', 108));int pathlength = -1;if (type == 1) { pathlength = stackSolver(contexto, mfile, strat); } else if (type == 2) { pathlength = queueSolver(contexto, mfile, strat); } else if (type == 3) { pathlength = recursiveSolver(contexto, mfile, strat, compare); } //else { }if (pathlength != -1) { System.out.printf(texto, solver, strat[0], strat[1], strat[2], strat[3], pathlength); } else { System.err.println("SALIDA NO ENCONTRADA."); }System.out.println(Utils.formatL("", '-', 108)); }
    ///**resolve un mapa usando una pila.*/public int stackSolver(Context contexto, int mfile, Movements[] strat) { Maze maze = new Maze();if (strat.length != 4) { return -1; }if (!maze.read(contexto, mfile)) { System.err.println("Error en recursiveSolver.");return -1; }System.out.println("Maze:\n" + maze.toString());System.out.println("Input:\n" + maze.getInput().print());int pathlength;pathlength = maze.deepSearchStack(maze.getInput(), strat);System.out.println(((pathlength != -1) ? "Output found, length of path: " + pathlength : "No path found."));System.out.println(maze.toString());System.out.printf("Final maze: %s%n", maze.pathPaint(maze.getOutput()));return pathlength; }
    ///**resolve un mapa usando una cola.*/public int queueSolver(Context contexto, int mfile, Movements[] strat) { Maze maze = new Maze();if (strat.length != 4) { return -1; }if (!maze.read(contexto, mfile)) { System.err.println("Error en recursiveSolver.");return -1; }System.out.println("Maze:\n" + maze.toString());System.out.println("Input:\n" + maze.getInput().print());int pathlength;pathlength = maze.breadthSearchQueue(maze.getInput(), strat);System.out.println(((pathlength != -1) ? "Output found, length of path: " + pathlength : "No path found."));System.out.println(maze.toString());System.out.printf("Final maze: %s%n", maze.pathPaint(maze.getOutput()));return pathlength; }
    ///**resolve un mapa usando un algoritmo recursivo.*/public int recursiveSolver(Context contexto, int mfile, Movements[] strat, boolean compare) { Maze maze = new Maze();if (strat.length != 4) { return -1; }if (!maze.read(contexto, mfile)) { System.err.println("Error en recursiveSolver.");return -1; }System.out.println("Maze:\n" + maze.toString() + "\n" + "Input:\n" + maze.getInput().print());int pathlength;Point out = maze.deepSearchRec(maze.getInput(), strat, compare);if (out != null) { pathlength = maze.pathPaint(out);System.out.printf("Output is in point: %s%n", out.toString()); } else { pathlength = -1; }System.out.println(((pathlength != -1) ? "Output found, length of path: " + pathlength : "No path found."));System.out.println(maze.toString());System.out.printf("Final maze: %s%n", maze.pathPaint(maze.getOutput()));return pathlength; }

    public void play(int idFile) {
        final Movements[] strat1 = {Movements.LEFT, Movements.UP, Movements.RIGHT, Movements.DOWN,};
        maze = new Maze();
        if (!maze.read(this, idFile)) { System.err.println("Error en play.read");return; }
        if (checkFile(idFile, strat1) != -1) {
            muestraMensaje(getResources().getString(R.string.encontrada));
            input = maze.getInput();
            output = maze.getOutput();
            actual = input;
            tvLaberinto.setText(maze.toString());
        } else { muestraMensaje(getResources().getString(R.string.noEncontrada));onFinish(null); }
    }

    /****************************************************************/
    public int checkFile(int mfile, Movements[] strat) {
        //InputStream file = getResources().openRawResource(mfile);//File file = new File(mfile);
        Maze mazeAux = new Maze();
        int pathlength;
        if (strat.length != 4) {
            return -1;
        }
        if (!mazeAux.read(this, mfile)) {
            muestraMensaje("Error en recursiveSolver.");
            return -1;
        }
//		System.out.println("Mapa:\n" + mazeAux.toString()+"\nInput:  " + mazeAux.getInput()+"\nOutput: " + mazeAux.getOutput());
        pathlength = mazeAux.deepSearchStack(mazeAux.getInput(), strat);
//		pathlength = mazeAux.breadthSearchQueue(mazeAux.getInput(), strat);
//		pathlength = mazeAux.pathPaint(mazeAux.deepSearchRec(mazeAux.getInput(), strat, false));
        return pathlength;
    }

    public void onBotonClick(View v) {
        if (!hasGanado) {
            Point neighbor;
            switch (v.getId()) {
                case R.id.up: { neighbor = maze.getNeighbor(actual, Movements.UP);break; }
                case R.id.down: { neighbor = maze.getNeighbor(actual, Movements.DOWN);break; }
                case R.id.left: { neighbor = maze.getNeighbor(actual, Movements.LEFT);break; }
                case R.id.right: { neighbor = maze.getNeighbor(actual, Movements.RIGHT);break; }
                default: { throw new IllegalStateException("Unexpected value: " + v.getId()); }
            }
            if (neighbor != null && !neighbor.isBarrier()) {
                if (!neighbor.isOutput()) {
                    if (!actual.isInput() && !actual.isOutput()) {
                        actual.setSymbol(FileChars.SPACE.c);
                    }
                    if (!neighbor.isInput()) {
                        neighbor.setSymbol(Movements.ACTUAL.c);
                    }
                } else {
                    System.out.println("isOutput");
                    actual.setSymbol(FileChars.SPACE.c);
                }
                moves++;// if(temp.equals(actual)==false){moves++;}
                TextView tv = findViewById(R.id.tvContador);
                tv.setText(String.format(getResources().getString(R.string.movimientos), moves));
                actual = neighbor;
            }

            tvLaberinto.setText(maze.toString());

            if (actual.equals(output)) {
                TextView tv = findViewById(R.id.tvContador);
                tv.setText(String.format(getResources().getString(R.string.movimientos), moves));
                muestraMensaje(String.format(getResources().getString(R.string.ganado), moves));
                onGanar();
            }
        } else {
            onFinish(v);
        }
    }

    public int getResourceId(String name, String defType) {
        return getResources().getIdentifier(name, defType, getPackageName());
    }

    protected void onGanar() {
        long id = 0;
        hasGanado = true;
        onPause();
        try {
            Ranking ranking = new Ranking(nombreJugador, laberintoType, moves);
            SQLiteHelper_Ranking db = SQLiteHelper_Ranking.getInstance(this);
            id = db.addOrUpdateRanking(ranking);/*db.addRanking(ranking);*/
//            actualizarBD();
        } catch (Exception e) {
            muestraMensaje("(" + id + ")" + e);
        }
//        actualizarBD();
    }

    protected void actualizarBD() {
        String txt = "Rankings:\n";
        try {
            SQLiteHelper_Ranking db = SQLiteHelper_Ranking.getInstance(this);
            List<Ranking> ranking = db.getAllRankings();
            for (Ranking r : ranking) {
                txt = String.format("%s%s\n", txt, r.toString(this));
            }
            ((TextView) findViewById(R.id.tvGanardores)).setText(txt);
        } catch (Exception e) {
            muestraMensaje(getResources().getString(R.string.errorGanardores));
        }
    }

    public void onFinish(View v) {
        onPause();/*setResult(RESULT_OK, new Intent().putExtra("respuesta", String.format(getResources().getString(R.string.ganado), movimientos)));*/
        finish();
    }

    public void musica(int music) {
        try {
            Musica.musicaRaw(this, music);
        } catch (IllegalArgumentException e) {
            Toast.makeText(getApplicationContext(), "" + e, Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    @Override
    public void onPause() {
        if (Musica.getMp() != null && Musica.getMp().isPlaying()) {
            Musica.onPause();
            Musica.retirar();
        }
        super.onPause();
    }

    protected void muestraMensaje(String txt) {
        Toast.makeText(this, txt, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
}

