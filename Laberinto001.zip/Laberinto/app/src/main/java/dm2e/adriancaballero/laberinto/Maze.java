package dm2e.adriancaballero.laberinto;

import android.content.Context;
import android.graphics.RectF;
import android.util.Log;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

/**
 *
 * @author Adrian Caballeo Orasio
 */
public class Maze {
    private int nX, nY;
    private Point[][] coord;
    /**
     * Inicializa un mapa, reservando memoria y devolviendo el mapa inicializado si lo ha hecho correctamente o NULL si no
     */
    public Maze() {
        this.coord = new Point[Utils.MAX][Utils.MAX];
        for (int y = 0; y < Utils.MAX; y++) {
            for (int x = 0; x < Utils.MAX; x++) {
                this.coord[x][y] = null;
            }
        }
        this.nX = -1;
        this.nY = -1;
    }

    ///** Libera la memoria dinamica reservada para un mapa */void map_destroy(Map *pl);

    /**
     * Devuelve el numero de filas de un mapa dado, o -1 si se produce algun error
     */
    public int getNcols() {
        return this.nX;
    }

    /**
     * Devuelve el numero de columnas de un mapa dado, o -1 si se produce algun error
     */
    public int getNrows() {
        return this.nY;
    }

    /**
     * Devuelve el punto de entrada en un mapa dado, o NULL si se produce algun error o no existe un punto de ese tipo
     */
    public Point getInput() {
        for (int y = 0; y < this.getNrows(); y++) {
            for (int x = 0; x < this.getNcols(); x++) {
                if (this.getPoint(x, y) != null && this.getPoint(x, y).isInput()) {
                    return this.getPoint(x, y);
                }
            }
        }
        return null;
    }

    /**
     * Devuelve el punto de salida en un mapa dado, o NULL si se produce algun error o no existe un punto de ese tipo
     */
    public Point getOutput() {
        for (int y = 0; y < this.getNrows(); y++) {
            for (int x = 0; x < this.getNcols(); x++) {
                if (this.getPoint(x, y) != null && this.getPoint(x, y).isOutput()) {
                    return this.getPoint(x, y);
                }
            }
        }
        return null;
    }

    public Point[][] getCoord() {
        return this.coord;
    }

    /**
     * Devuelve el punto situado en (x,y), o NULL si se produce algun error
     */
    public Point getPoint(int x, int y) {
        if (x < 0 || x > this.getNcols() || y < 0 || y > this.getNrows()) {
            return null;
        }
        return this.coord[x][y];
    }

    /**
     * Devuelve el punto resultante al realizar un movimiento en un mapa a partir de un punto inicial, o NULL si se produce algun error
     */
    public Point getNeighbor(Point p, Movements strat) {
        if (p == null || strat != Movements.RIGHT && strat != Movements.UP && strat != Movements.LEFT && strat != Movements.DOWN) {
            return null;
        }
        int x = p.getX(), y = p.getY();
        switch (strat) {
            case UP:    { if (x > 0              ) { if ((this.getPoint(x - 1, y) != null)) { x--; } else { System.err.printf("coord[%d-1][%d] no existe\n", x, y); } } else { System.err.printf("coord[%d-1][%d] x es menor que 0\n",     x, y); }break; }
            case DOWN:  { if (x < this.getNcols()) { if ((this.getPoint(x + 1, y) != null)) { x++; } else { System.err.printf("coord[%d+1][%d] no existe\n", x, y); } } else { System.err.printf("coord[%d+1][%d] x es mayor que nX=%d\n", x, y, this.getNcols()); }break; }
            case LEFT:  { if (y > 0              ) { if ((this.getPoint(x, y - 1) != null)) { y--; } else { System.err.printf("coord[%d][%d-1] no existe\n", x, y); } } else { System.err.printf("coord[%d][%d-1] y es menor que 0\n",     x, y); }break; }
            case RIGHT: { if (y < this.getNrows()) { if ((this.getPoint(x, y + 1) != null)) { y++; } else { System.err.printf("coord[%d][%d+1] no existe\n", x, y); } } else { System.err.printf("coord[%d][%d+1] y es mayor que nY=%d\n", x, y, this.getNrows()); }break; }
        }
//        return (!this.getPoint(x,y).isBarrier()) ? this.getPoint(x,y) : p;
        return this.getPoint(x, y);
    }

    /**
     * Indica el tamaño de un mapa, devuelve NULL si se produce algun error
     */
    public boolean setSize(int nX, int nY) {
        if (nX <= 0 || nX > Utils.MAX || nY <= 0 || nY > Utils.MAX) {
            return false;
        }
        this.setNcols(nX);
        this.setNrows(nY);
        return true;
    }

    /**
     * Añade un punto a un mapa dado reservando nueva memoria (de ahi que el
     * argumento sea declarado como const), o modifica el punto si ya se encuentra.
     * Debe comprobar si el punto es de tipo Output o Input para guardarlo como
     * corresponda. Devuelve OK si tod o ha ido correctamente (se ha podido
     * incluir/actualizar el punto).
     */
    public boolean setPoint(Point p) {
        if (p == null) {//Log.e("Maze.java","error en setPoint");
            return false;
        }
        int x = p.getX(), y = p.getY();
        if (x < 0 || x > this.getNcols() || y < 0 || y > this.getNrows()) {
            return false;
        }
        if (p.getSymbol() == FileChars.INPUT.c && getInput() != null) {
            this.getInput().setSymbol(FileChars.SPACE.c);
        } else if (p.getSymbol() == FileChars.OUTPUT.c && getOutput() != null) {
            this.getOutput().setSymbol(FileChars.SPACE.c);
        }
        this.coord[x][y] = p;
        return true;
    }

    public boolean setPoint(int x, int y, char symbol) {
        return (this.setPoint(new Point(x, y, symbol))); }
    public void setNcols(int nX) {
        this.nX = nX;
    }
    public void setNrows(int nY) {
        this.nY = nY;
    }
    public void setCoord(Point[][] coord) {
        this.coord = coord;
    }

    /**
     * Imprime en un fichero dado los datos de un mapa. Ademas, devolvera el numero
     * de caracteres que se han escrito con exito (mirar documentacion de fprintf)
     */
//	int map_print(FILE *file, const Map *pl);
//    public int length() { String txt = String.format("%s", this.toString());return txt.toCharArray().length; }
    @Override public String toString() { StringBuilder txt = new StringBuilder();for (int x = 0; x < this.getNcols(); txt.append("\n"), x++) { for (int y = 0; y < this.getNrows(); y++) { try { txt.append(String.format("%c", this.getPoint(x, y).getSymbol())); } catch (Exception e) { Log.e("Maze.java","[" + x + "," + y + "] en [" + this.getNcols() + "," + this.getNrows() + "]"); } } }return txt.toString(); }
    public String toCoordString() { StringBuilder txt = new StringBuilder();for (int x = 0; x < this.getNcols(); txt.append("\n"), x++) { for (int y = 0; y < this.getNrows(); y++) { try { txt.append(String.format("%s", this.getPoint(x, y))); } catch (Exception e) { txt.append(String.format("[(%2d, %2d) %s]", x, y, FileChars.ERRORCHAR.c)); } } }return txt.toString(); }
    /**Lee los datos de un archivo necesarios de un archivo para crear un mapa.*/
    public boolean read(Context contexto, int pf) {/* asignamos dimension al laberinto */List<String> lineas = null;try { lineas = new ArrayList<>();InputStream is = contexto.getApplicationContext().getResources().openRawResource(pf);Scanner sc = new Scanner(is);if (sc.hasNextLine()) { while (sc.hasNextLine()) { lineas.add(sc.nextLine()); } }sc.close();is.close(); } catch (Exception e) { e.printStackTrace(); }if (lineas == null) { Log.e("Maze.java","Error in Maze.read.Files.readAllLines()");return false; }int nX = Integer.parseInt(lineas.get(0).split(" ")[0]), nY = Integer.parseInt(lineas.get(0).split(" ")[1]);if (!this.setSize(nX, nY)) { Log.e("Maze.java","Error in read.setSize()");return false; }/* leemos el fichero linea a linea */for (int x = 0; x < nX; x++) { char[] buff = lineas.get(x + 1).toCharArray();for (int y = 0; y < nY; y++) { this.setPoint(new Point(x, y, buff[y])); } }return true; }
//    public boolean read0(Context contexto, int pf) {/* creamos punto que se utiliza como buffer */Point temp = new Point(0, 0, FileChars.ERRORCHAR.c);if(temp==null){Log.e("Maze.java","Error in read.temp = new Point()");return false;}/* asignamos dimension al laberinto */List<String> lineas = null;try { lineas = new ArrayList<>();InputStream is = contexto.getApplicationContext().getResources().openRawResource(pf);Scanner sc = new Scanner(is);if (sc.hasNextLine()) { while (sc.hasNextLine()) { lineas.add(sc.nextLine()); } }sc.close();is.close(); } catch (Exception e) { e.printStackTrace(); }if (lineas == null) { Log.e("Maze.java","Error in Maze.read.Files.readAllLines()");return false; }int nX = Integer.parseInt(lineas.get(0).split(" ")[0]), nY = Integer.parseInt(lineas.get(0).split(" ")[1]);boolean st = this.setSize(nX, nY);if (!st) { Log.e("Maze.java","Error in read.setSize()");return false; }/* leemos el fichero linea a linea */for (int x = 0; x < nX; x++) { char[] buff = lineas.get(x + 1).toCharArray();for (int y = 0; y < nY; y++) { char c = buff[y];/* ajustamos los atributos del punto leido (falta añadir control de errores) */if (!temp.setX(x)) {Log.e("Maze.java","Error in read.temp.setX(" + x + ")");}if (!temp.setY(y)) {Log.e("Maze.java","Error in read.temp.setY(" + x + ")");}if (!temp.setSymbol(c)) {Log.e("Maze.java","Error in read.temp.setSymbol(" + c + ")");}/* insertamos el punto en el laberinto (falta añadir control de errores) */if (!this.setPoint(temp)) {Log.e("Maze.java","Error in read.temp.setPoint(" + temp + ")");} } }return true; }
    /**Pasa los datos de un mapa a una pila, Null en caso de error*/public Stack<Point> toStack() { Stack<Point> stack = new Stack<>();for (int y = 0; y < this.getNrows(); y++) { for (int x = 0; x < this.getNcols(); x++) { if (stack.size() == this.getNrows() * this.getNcols()) { Log.e("Maze.java","Stack is too small for maze.");return null; }Point cp = this.getPoint(x, y);if (stack.push(cp) == null) { Log.e("Maze.java","Error while adding point to stack.");return null; } } }return stack; }
    /**Pasa los datos de un mapa a una cola, Null en caso de error.*/
    public Queue<Point> toQueue() { Queue<Point> queue = new LinkedList<>();for (int y = 0; y < this.getNrows(); y++) { for (int x = 0; x < this.getNcols(); x++) { if (queue.size() == this.getNrows() * this.getNcols()) { Log.e("Maze.java","Queue is too small for maze.");return null; }Point cp = this.getPoint(x, y);if (!queue.add(cp)) { Log.e("Maze.java","Error while adding point to queue.\n");return null; } } }return queue; }
    /**Realiza el recorrido completo de un mapa en busca del OUTPUT desde el INPUT, usa una pila.*/
    public int deepSearchStack(Point input, Movements[] strat) { Stack<Point> stack = new Stack<>();stack.push(input);while (!stack.isEmpty()) { Point cp = stack.pop();if (cp.getSymbol() != Movements.VISITED.c) { if (!this.getPoint(cp.getX(), cp.getY()).setSymbol(Movements.VISITED.c)) { return -1; }for (int i = strat.length - 1; i >= 0; i--) {/* stack is LIFO-> movements with higher preference have to be checked last */Point neighbor = this.getNeighbor(cp, strat[i]);if (neighbor != null) { if (neighbor.isOutput()) { neighbor.setParent(this.getPoint(cp.getX(), cp.getY()));return this.pathPaint(neighbor); }if (neighbor.isSpace()) { neighbor.setParent(this.getPoint(cp.getX(), cp.getY()));if (stack.push(neighbor) == null) { Log.e("Maze.java","Error in stack_push.");return -1; } } } } } }return -1; }
    /**Realiza el recorrido completo de un mapa en busca del OUTPUT desde el INPUT, usa una cola.*/
    public int breadthSearchQueue(Point input, Movements[] strat) { Queue<Point> queue = new LinkedList<>();queue.add(input);while (!queue.isEmpty()) { Point cp = queue.remove();if (cp.getSymbol() != Movements.VISITED.c) { if (!cp.isInput()) { if (!this.getPoint(cp.getX(), cp.getY()).setSymbol(Movements.VISITED.c)) { return -1; } }for (Movements movements : strat) {/* queue is FIFO-> movements with higher preference have to be checked first */Point neighbor = this.getNeighbor(cp, movements);if (neighbor != null) { if (neighbor.isOutput()) { neighbor.setParent(this.getPoint(cp.getX(), cp.getY()));return this.pathPaint(neighbor); }if (neighbor.isSpace()) { neighbor.setParent(this.getPoint(cp.getX(), cp.getY()));if (!queue.add(neighbor)) { Log.e("Maze.java","Error in queue_insert.\n");return -1; } } } } } }return -1; }
    public Point deepSearchRec(Point input, Movements[] strat, boolean compare) { if (compare) { System.out.println("Current maze:\n" + this.toString()); }if (input.isOutput()) { return input; }input.setSymbol(Movements.VISITED.c);for (Movements movements : strat) { Point neighbor = this.getNeighbor(input, movements);if (neighbor != null) { if (neighbor.getSymbol() != Movements.VISITED.c && neighbor.getSymbol() != Movements.ACTUAL.c && neighbor.getSymbol() != FileChars.BARRIER.c) { neighbor.setParent(this.getPoint(input.getX(), input.getY()));if (!neighbor.isOutput()) { neighbor.setSymbol(Movements.ACTUAL.c); }Point auxpoint = this.deepSearchRec(neighbor, strat, compare);if (auxpoint != null) {/*if(auxpoint.getParent().equals(input)){if(compare==true){System.out.println("Solution!");paintPath();}}*/return auxpoint; } } } }return null; }
    public int pathPaint(Point output) { int pathlength = 0;Point cp = output;if (cp == null) { return -1; }while (cp.getParent() != null) { if (cp.getParent().getX() > cp.getX()) { cp.getParent().setSymbol(Movements.UP.c); } else if (cp.getParent().getX() < cp.getX()) { cp.getParent().setSymbol(Movements.DOWN.c); } else if (cp.getParent().getY() > cp.getY()) { cp.getParent().setSymbol(Movements.LEFT.c); } else if (cp.getParent().getY() < cp.getY()) { cp.getParent().setSymbol(Movements.RIGHT.c); } else { cp.getParent().setSymbol(Movements.ACTUAL.c); }cp = cp.getParent();pathlength++; }cp.setSymbol(FileChars.INPUT.c);output.setSymbol(FileChars.OUTPUT.c);return pathlength; }
    public void paintPath() { Point cp = this.getOutput();if (cp == null) { return; }while (cp.getParent() != null) { System.out.print(cp + " <-- ");cp = cp.getParent(); }cp.setSymbol(FileChars.INPUT.c);System.out.println(cp); }
    public void startMazeText() { Scanner scan = new Scanner(System.in);Point input = this.getInput(), output = this.getOutput(), actual = input;int moves = 0;char move;System.out.println("START");while (!actual.equals(output)) { System.out.println(Utils.formatL("", '-', 108));System.out.println(this.toString());System.out.printf("Moves: %3d              w%nIntroduce movimiento: a s d: ", moves);move = scan.next().charAt(0);try { Point neighbor;switch (move) { case 'a': { neighbor = this.getNeighbor(actual, Movements.LEFT);break; } case 'd': { neighbor = this.getNeighbor(actual, Movements.RIGHT);break; } case 'w': { neighbor = this.getNeighbor(actual, Movements.UP);break; } case 's': { neighbor = this.getNeighbor(actual, Movements.DOWN);break; } default: { throw new IllegalArgumentException("Unexpected value: " + move); } }if (!neighbor.isOutput()) { if (!actual.isInput() && !actual.isOutput()) { actual.setSymbol(FileChars.SPACE.c); }if (!neighbor.isInput()) { neighbor.setSymbol(Movements.ACTUAL.c); } } else { System.out.println("isOutput");actual.setSymbol(FileChars.SPACE.c); }moves++;/* if(temp.equals(actual)==false){moves++;} */actual = neighbor; } catch (Exception e) { Log.e("Maze.java", String.valueOf(e)); } }System.out.println(Utils.formatL("", '-', 108));System.out.println(this.toString());System.out.println("YOU WIN!! in " + moves + " MOVESMENTS");scan.close(); }
}
