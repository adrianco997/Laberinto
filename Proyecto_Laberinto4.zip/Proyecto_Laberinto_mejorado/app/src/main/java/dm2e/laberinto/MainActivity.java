package dm2e.laberinto;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build.VERSION;
import android.os.Build.VERSION_CODES;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.ColorRes;
import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

/**
 * @author Adrian Caballeo Orasio
 */
public class MainActivity extends AppCompatActivity {
    private static final int MAZE_PLAYER_TEXT_ACTIVITY_TAG = 1;
    private static final int MAZE_PLAYER_DRAW_ACTIVITY_TAG = 2;
    private final String TAG = getClass().getName();
    private String laberinto = "";
    private String modo = "";

    private int lp_mp = LayoutParams.MATCH_PARENT;
    private int lp_wc = LayoutParams.WRAP_CONTENT;
    private int ll_v = LinearLayout.VERTICAL;
    private int ll_h = LinearLayout.HORIZONTAL;
    private int g_c = Gravity.CENTER;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        actualizarBD((TextView) findViewById(R.id.tvGanardores));
        makeMazesButtons(R.id.rgMazes, 1, ll_v);
        makeModesButtons(R.id.rgModes, 2, ll_v);
    }

//    public int findId() { View v = findViewById(ids);while (v != null) v = findViewById(++ids);return ids++; }private static int ids = 1;

    //@ColorRes

    int background_Buttons = R.color.color_rm;
    public void makeMazesButtons(@IdRes int rgId, int modulo, int orientation) {
        RadioGroup rg = findViewById(rgId);
        rg.setLayoutParams(new RadioGroup.LayoutParams(lp_mp, lp_wc));
        rg.setOrientation(orientation);
        rg.setGravity(g_c);
        LinearLayout ll = null;
        for (int i = 1; Utils.getResourceId(this, "m" + i, "raw") != 0; i++) {
            if ((i - 1) % modulo == 0) {
                if (ll != null) rg.addView(ll);
                ll = new LinearLayout(this);
                ll.setLayoutParams(new RadioGroup.LayoutParams(lp_wc, lp_wc, 1f));
                ll.setOrientation((rg.getOrientation() != ll_v) ? ll_v : ll_h);
                ll.setGravity(g_c);
            }
            RadioButton rb = new RadioButton(this);
            String txt = getString(R.string.maze_txt, i);//getString((int) Utils.getResourceId(this,"m" + i, "raw"));
            rb.setText(txt);
            rb.setTag("m" + i);

            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(lp_wc, lp_wc, 1f);
            params.setMargins(10, 10, 10, 10);
            rb.setLayoutParams(params);
            rb.setPadding(10, 10, 10, 10);
            rb.setBackgroundColor(getResources().getColor(background_Buttons));
            rb.setButtonDrawable(R.drawable.radiobutom);

            rb.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Log.i(TAG, "onClick Mazes." + v.getTag() + ": " + v.getId() + " : " + ((RadioButton) v).getText());
                    RadioGroup rgMazes = (RadioGroup) v.getParent().getParent();//findViewById(R.id.rgMazes);
                    for (int i = 0; i < rgMazes.getChildCount(); i++) {
                        LinearLayout ll = (LinearLayout) rgMazes.getChildAt(i);
                        for (int j = 0; j < ll.getChildCount(); j++) {
                            if (ll.getChildAt(j) != v)
                                ((RadioButton) ll.getChildAt(j)).setChecked(false);
                        }
                    }
                    if (v.getTag() != null) laberinto = (String) v.getTag();
                    else laberinto = "";
                }
            });
            ll.addView(rb);
        }
        if (ll != null) rg.addView(ll);
    }




    public void makeModesButtons(@IdRes int rgId, int modulo, int orientation) {
        RadioGroup rg = findViewById(rgId);
        rg.setLayoutParams(new RadioGroup.LayoutParams(lp_mp, lp_wc));
        rg.setOrientation(orientation);
        rg.setGravity(g_c);
        String[] modos = getResources().getStringArray(R.array.modos);
        LinearLayout ll = null;
        for (int i = 0; i < modos.length; i++) {
            if (i % modulo == 0) {
                if (ll != null) rg.addView(ll);
                ll = new LinearLayout(this);
                ll.setLayoutParams(new RadioGroup.LayoutParams(lp_wc, lp_wc, 1f));
                ll.setOrientation((rg.getOrientation() != ll_v) ? ll_v : ll_h);
                ll.setGravity(g_c);
            }
            RadioButton rb = new RadioButton(this);
            rb.setText(modos[i]);
            rb.setTag(modos[i]);

            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(lp_wc, lp_wc, 1f);
            params.setMargins(10, 10, 10, 10);
            rb.setLayoutParams(params);
            rb.setPadding(10, 10, 10, 10);
            rb.setBackgroundColor(getResources().getColor(background_Buttons));
            rb.setButtonDrawable(R.drawable.radiobutom);

            rb.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Log.i(TAG, "onClick Modes." + v.getTag() + ": " + v.getId());
                    RadioGroup rgModes = (RadioGroup) v.getParent().getParent();//findViewById(R.id.rgModes);
                    for (int i = 0; i < rgModes.getChildCount(); i++) {
//                        if (rgModes.getChildAt(i) != v) ((RadioButton) rgModes.getChildAt(i)).setChecked(false);
                        LinearLayout ll = (LinearLayout) rgModes.getChildAt(i);
                        for (int j = 0; j < ll.getChildCount(); j++) {
                            if (ll.getChildAt(j) != v)
                                ((RadioButton) ll.getChildAt(j)).setChecked(false);
                        }
                    }
                    if (v.getTag() != null) modo = (String) v.getTag();
                    else modo = "";
                }
            });
            ll.addView(rb);
        }
        if (ll != null) rg.addView(ll);
    }

    public void onPulsar(View v) {
        String nombre = ((EditText) findViewById(R.id.etNombre)).getText().toString().trim();
        if (nombre.equals("")) Utils.muestraMensaje(this, R.string.nombreInvalido);
        else if (this.laberinto.equals("")) Utils.muestraMensaje(this, R.string.laberintoInvalido);
//        else if (modo.equals("")){ Utils.muestraMensaje(this,R.string.modoInvalido); }
        else {
            /*witch (R.string) {}*/
            if (modo.equals(getString(R.string.modo_texto))) {
                startIntent(nombre, MazePlayerTextActivity.class, MAZE_PLAYER_TEXT_ACTIVITY_TAG);
            } else if (modo.equals(getString(R.string.modo_dibujo))) {
                startIntent(nombre, MazePlayerDrawActivity.class, MAZE_PLAYER_DRAW_ACTIVITY_TAG);
            } else Utils.muestraMensaje(this, R.string.modoInvalido);
        }
    }

    public void startIntent(String nombre, Class clase, int activityTag) {
        Intent intent = new Intent(this, clase);
        intent.putExtra("nombre", nombre);
        intent.putExtra("laberinto", this.laberinto);
        startActivityForResult(intent, activityTag);
    }

    /***********************************************************************************************/
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_settings: {
                return true;
            }
            case R.id.menu_ranking: {
                final View v = findViewById(R.id.menu_settings);/*item.getActionView()*/
                openPopup(v, R.id.menu_ranking);
                return true;
            }
            case R.id.menu_help: {
                final View v = findViewById(R.id.menu_settings);/*item.getActionView()*/
                openPopup(v, R.id.menu_help);
                return true;
            }
            case R.id.menu_info: {
                final View v = findViewById(R.id.menu_settings);/*item.getActionView()*/
                openPopup(v, R.id.menu_info);
                return true;
            }
            default: {
                return super.onOptionsItemSelected(item);
            }
        }
    }

    public void openPopup(View view) {
        Utils.openPopup(this, view, view.getId());
    }

    public void openPopup(View view, /*@IdRes*/ int idPopup) {
        Utils.openPopup(this, view, idPopup);
    }

    /***********************************************************************************************/
//    public void selectLaberinto(View v) { Log.i(TAG, "selectLaberinto raw.m" + v.getTag() + ": " + v.getId());if (v.getId() == R.id.laberinto1) this.laberinto = getString(R.string.laberinto_1);else if (v.getId() == R.id.laberinto2) this.laberinto = getString(R.string.laberinto_2);else if (v.getId() == R.id.laberinto3) this.laberinto = getString(R.string.laberinto_3);else if (v.getId() == R.id.laberinto4) this.laberinto = getString(R.string.laberinto_4);else this.laberinto = ""; }
//    public void selectModo(View v) { Log.i(TAG, "onClick StringArray.modo." + v.getTag() + ": " + v.getId());if (v.getId() == R.id.modo1) this.modo = getString(R.string.modo_texto);else if (v.getId() == R.id.modo2) this.modo = getString(R.string.modo_dibujo);else this.modo = ""; }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);/*String respuesta = data.getStringExtra("respuesta");*//*if(resultCode==RESULT_FIRST_USER){}else if(resultCode==RESULT_OK){}else if(resultCode==RESULT_CANCELED){}*/
        Musica.release();
//        actualizarBD((TextView) findViewById(R.id.tvGanardores));
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
}