package dm2e.laberinto;

import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RawRes;
import androidx.appcompat.app.AppCompatActivity;

/**
 * @author Adrian Caballeo Orasio
 */
public class MazePlayerDrawActivity extends AppCompatActivity {
    private final String TAG = getClass().getName();
    private String laberintoType = "error", nombreJugador = "";
    private Point actual = null, input = null, output = null;
    private MazeView mazeViewer = null;
    private TextView tvContador = null;
    private boolean hasGanado = false;
    private Maze maze = null;
    private int moves = 0;
    private int cells;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mazeplayer_draw);

        this.mazeViewer = findViewById(R.id.MazeView);
        this.mazeViewer.setScaleType(ImageView.ScaleType.MATRIX);

        String[] intent = Utils.getIntentInfo(getIntent());
        this.nombreJugador = intent[0];
        this.laberintoType = intent[1];

        this.tvContador = findViewById(R.id.tvContador);
        Utils.muestraMensaje(this, String.format(getResources().getString(R.string.ordenaLaberinto), this.nombreJugador));

        findViewById(R.id.up).setOnClickListener(new DpadDrawClick());
        findViewById(R.id.down).setOnClickListener(new DpadDrawClick());
        findViewById(R.id.left).setOnClickListener(new DpadDrawClick());
        findViewById(R.id.right).setOnClickListener(new DpadDrawClick());

        iniPlay(this.laberintoType);
    }

    public void iniPlay(String laberintoType) {
        if (!play(Utils.getResourceId(this, laberintoType, "raw"))) onFinish(null);
        this.moves = 0;
        this.hasGanado = false;
        this.tvContador.setText(String.format(getResources().getString(R.string.movimientos), this.moves));
    }

    public void restart() {
        this.maze = null;
        this.input = null;
        this.output = null;
        this.actual = null;
        this.hasGanado = false;
    }

    public boolean play(@RawRes int idFile) {
        restart();
        this.mazeViewer.restart();
        this.maze = new Maze(this);
        if (!this.maze.read(idFile)) {
            Log.e(TAG, "Error en play.read");
            return false;
        }
        if (Utils.checkFile(this, idFile) != -1) {
//            Utils.muestraMensaje(this,getResources().getString(R.string.encontrada));
            if (this.input == null) this.input = maze.getInput();
            if (this.output == null) this.output = maze.getOutput();
            if (this.actual == null) this.actual = this.input;
            Log.i(TAG, "input: " + this.input + ", output: " + this.output + ", actual: " + this.actual);

            this.cells = Utils.getZoom();
            this.mazeViewer.setZoom(this.cells);
            printMaze();
            return true;
        } else {
            Utils.muestraMensaje(this, getResources().getString(R.string.noEncontrada));
            return false;
        }
    }


    /***********************************************************************************************/
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_mazeplayer_text, menu);
        Utils.onCreateOptionsMenuItems(this, menu, true);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.musica: {
                item.setIcon(Utils.musicaPlayStop(this, false));
                return true;
            }
            case R.id.x_size: {
                this.cells = mazeViewer.addZoom();
                printMaze();
                //item.setTitle(getString(R.string.x_size, this.cells));
                return true;
            }
            /*case R.id.y_size: {
                this.cells = mazeViewer.addZoom();
                //item.setTitle(getString(R.string.y_size, this.cells));
                printMaze();
                return true;
            }*/
            case R.id.restart: {
                Utils.muestraMensaje(this, "restart");
                iniPlay(this.laberintoType);
                return true;
            }
            case R.id.help: {
                final View v = findViewById(R.id.action_settings);
                Utils.openPopup(this, v, R.id.help);
                return true;
            }
            default: {
                return super.onOptionsItemSelected(item);
            }
        }
    }

//    public void openPopup(View view) { Utils.openPopup(this, view, view.getId()); }
//    public void openPopup(View view, /*@IdRes*/ int idPopup) { Utils.openPopup(this, view, idPopup); }

    /***********************************************************************************************/
    private class DpadDrawClick implements View.OnClickListener {
        public void onClick(View v) {
            if (!hasGanado && actual != null) {
                Point neighbor = Utils.getNeighbor(v, maze, actual);
                if (neighbor != null && !neighbor.isErrorChar() && !neighbor.isBarrier()) {
                    actual = neighbor;
                    moves++;
                    tvContador.setText(String.format(getResources().getString(R.string.movimientos), moves));
                }
                printMaze();
                if (actual.equals(output)) {
                    tvContador.setText(String.format(getResources().getString(R.string.movimientos), moves));
                    Utils.muestraMensaje(getBaseContext(), String.format(getResources().getString(R.string.ganado), moves));
                    onGanar();
                }
            } else onFinish(v);
        }
    }

    protected void onGanar() {
        this.hasGanado = Utils.onGanar(this, TAG, this.nombreJugador, this.laberintoType, this.moves);
    }

    public void printMaze() {
        this.mazeViewer.setActual(actual);
        this.mazeViewer.setMaze(this.maze);
        this.mazeViewer.invalidate();
        //this.mazeViewer.drawMaze(this.maze, this.actual);

    }

    /****************************************************************/
    public void onFinish(View v) {
        /*setResult(RESULT_OK, new Intent().putExtra("respuesta", String.format(getResources().getString(R.string.ganado), movimientos)));*/
        Musica.stop();
        Musica.release();
        finish();
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

//    @Override protected void onPostResume() { super.onPostResume(); }
//    @Override protected void onStart() { super.onStart(); }
//    @Override protected void onStop() { super.onStop(); }
//    @Override protected void onDestroy() { super.onDestroy(); }
//    @Override public void invalidateOptionsMenu() { super.invalidateOptionsMenu(); }
//    @Override public void onContentChanged() { super.onContentChanged(); }
//    @Override public Resources getResources() { return super.getResources(); }
//    @Override public void openOptionsMenu() { super.openOptionsMenu(); }
//    @Override public void closeOptionsMenu() { super.closeOptionsMenu(); }
}
