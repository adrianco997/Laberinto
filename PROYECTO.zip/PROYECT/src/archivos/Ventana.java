package archivos;

import javax.swing.JFrame;

public class Ventana extends JFrame
{
	public Ventana()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.add(new Dibujar());
		this.setTitle("Movimiento personaje");
		this.setSize(800, 600);
		this.setVisible(true);
		this.setLocationRelativeTo(null); // Para centrar la ventana
		this.setResizable(false);
	}
	
	public static void main(String[] args)
	{
		new Ventana();
		
	}
}
