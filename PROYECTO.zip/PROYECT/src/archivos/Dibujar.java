package archivos;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JPanel;
import javax.swing.Timer;

public class Dibujar extends JPanel implements ActionListener
{
	private Personaje persona;
	private Timer timer;

	public Dibujar() 
	{
		this.setBackground(Color.WHITE);	// Color de fondo
		this.setFocusable(true); // Con esto el teclado detecta el color
		this.addKeyListener(new teclado());	// Declaramos la clase teclado
		
		persona = new Personaje();
		timer = new Timer(1, this); // Con esto manejamos la velocidad a la que se movera nuestro personaje
		timer.start();				// Empieza a contar y cada 5 milisegundos efectuara un cambio
	}


	public void paint(Graphics grafica)	// Dibujamos al personaje 
	{
		super.paint(grafica);
		Graphics2D g2 = (Graphics2D) grafica;
		g2.drawImage(persona.tenerImagen(), persona.tenerX(), persona.tenerY(), null); // Dibuja la imagen
		
	}





	@Override
	public void actionPerformed(ActionEvent e) 	// Con esto ejecutamos la accion mover 
	{
		persona.mover();
		repaint();	// Con esto volvemos a dibujar la imagen en el tablero 
		
	}
	
	private class teclado extends KeyAdapter	// Llamamos a los eventos de key
	{
		public void keyReleased(KeyEvent e)
		{
			persona.keyReleased(e);
		}
		
		public void keyPressed(KeyEvent e)
		{
			persona.keyPressed(e);
		}
	}
	
}
