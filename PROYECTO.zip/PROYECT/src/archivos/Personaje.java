package archivos;

import java.awt.Image;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;

public class Personaje 
{
	private String persona = "persona.png";
	
	private int dx;
	private int dy;
	private int x;
	private int y;
	
	private Image imagen;

	public Personaje() // Constructor
	{
		this.x = 400;
		this.y = 60;
		ImageIcon img = new ImageIcon(this.getClass().getResource(persona));	// Con esto buscamos el recurso llamado persona
		this.imagen = img.getImage();	// Llamamos al archivo persona
	}
	
	public void mover() // Con esto representamos la posicion de la imegen
	{
		x += dx;
		y += dy;
	}
	
	public int tenerX() // Con esto retornamos el valor de x obtenido en los metodos
	{
		return x;
	}
	
	public int tenerY()
	{
		return y;
	}
	
	public Image tenerImagen()
	{
		return imagen;
	}

	
	public void keyPressed(KeyEvent e) // Eventos que responden al teclado
	{
		int key = e.getKeyCode();	// Obtenemos cada numero de nuestro teclado
		
		if (key == KeyEvent.VK_LEFT) 
		{
			dx = -1;			// Con esto rota hacia la izquierda.
		}
		
		if (key == KeyEvent.VK_RIGHT) 
		{
			dx = 1;
		}
		
		if (key == KeyEvent.VK_UP) 
		{
			dy = -1;			// Al subir disminuye su posicion en y 
		}
		
		if (key == KeyEvent.VK_DOWN) 
		{
			dy = 1;
		}
	}
	
	public void keyReleased(KeyEvent e)	// Esto es para cuando dejamos de presionar las teclas 
	{
		int key = e.getKeyCode();
		
		if (key == KeyEvent.VK_LEFT) 
		{
			dx = 0;	// Para que el objeto deje de moverse
		}
		
		if (key == KeyEvent.VK_RIGHT) 
		{
			dx = 0;
		}
		
		if (key == KeyEvent.VK_UP) 
		{
			dy = 0;
		}
		
		if (key == KeyEvent.VK_DOWN) 
		{
			dy = 0;
		}
	}
	
}
