package dm2e.laberinto;

import android.app.Application;
import android.os.SystemClock;

/**
 * @author Carlos del Valle Pelaez
 */
public class Splash extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        //SystemClock.sleep(5000);
        SystemClock.sleep(3000);
    }
}
