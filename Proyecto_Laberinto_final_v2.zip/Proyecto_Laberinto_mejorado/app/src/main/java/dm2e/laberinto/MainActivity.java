package dm2e.laberinto;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

/**
 * @author Adrian Caballeo Orasio
 */
public class MainActivity extends AppCompatActivity {
    private static final int MAZE_PLAYER_TEXT_ACTIVITY_TAG = 1;
    private static final int MAZE_PLAYER_DRAW_ACTIVITY_TAG = 2;
    private final String TAG = getClass().getName();
    private String laberinto = "";
    private String modo = "";

    private static final int lp_mp = LayoutParams.MATCH_PARENT;
    private static final int lp_wc = LayoutParams.WRAP_CONTENT;
    private static final int ll_v = LinearLayout.VERTICAL;
    private static final int ll_h = LinearLayout.HORIZONTAL;
    private static final int g_c = Gravity.CENTER;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        actualizarBD((TextView) findViewById(R.id.tvGanardores));
        makeMazesButtons(R.id.rgMazes, 1, ll_v);
        makeModesButtons(R.id.rgModes, 2, ll_v);
    }

//    public int findId() { View v = findViewById(ids);while (v != null) v = findViewById(++ids);return ids++; }private static int ids = 1;

    public RadioGroup RadioGroup_Style(@IdRes int rgId, int orientation) {
        RadioGroup rg = findViewById(rgId);
        rg.setLayoutParams(new RadioGroup.LayoutParams(lp_mp, lp_wc));
        rg.setOrientation(orientation);
        rg.setGravity(g_c);
        return rg;
    }

    public RadioButton RadioButton_Style(String text, String tag) {
        RadioButton rb = new RadioButton(new ContextThemeWrapper(this, R.style.cartel_button));
        rb.setText(text);
        rb.setTag(tag);
        RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(lp_wc, lp_wc, 1f);
        int top = 10;//((int) getResources().getDimension(R.dimen.activity_margin_top_separator));
        params.setMargins(10, top, 10, 10);
        rb.setPadding(10, 10, 10, 10);
        rb.setBackground(this.getResources().getDrawable(R.drawable.pergamino_1));
        //rb.setBackgroundColor(getResources().getColor(R.color.color_rm));
        rb.setButtonDrawable(R.drawable.radiobutton);
        rb.setLayoutParams(params);
        return rb;
    }

    public void makeMazesButtons(@IdRes int rgId, int modulo, int orientation) {
        RadioGroup rg = RadioGroup_Style(rgId, orientation);
        LinearLayout ll = null;
        for (int i = 1; Utils.getResourceId(this, "m" + i, "raw") != 0; i++) {
            if ((i - 1) % modulo == 0) {
                if (ll != null) rg.addView(ll);
                ll = new LinearLayout(this);
                ll.setLayoutParams(new RadioGroup.LayoutParams(lp_wc, lp_wc, 1f));
                ll.setOrientation((rg.getOrientation() != ll_v) ? ll_v : ll_h);
                ll.setGravity(g_c);
            }
            RadioButton rb = RadioButton_Style(getString(R.string.maze_txt, i), "m" + i);//getString((int) Utils.getResourceId(this, "m" + i, "raw"));
            rb.setOnClickListener(new View.OnClickListener() {
                String log_txt = "Mazes", value_txt = "laberinto";

                public void onClick(View v) {
                    onClickValue(v, log_txt, value_txt);
                }
            });
            ll.addView(rb);
        }
        if (ll != null) rg.addView(ll);
    }

    public void makeModesButtons(@IdRes int rgId, int modulo, int orientation) {
        String[] modos = getResources().getStringArray(R.array.modos);
        RadioGroup rg = RadioGroup_Style(rgId, orientation);
        LinearLayout ll = null;
        for (int i = 0; i < modos.length; i++) {
            if (i % modulo == 0) {
                if (ll != null) rg.addView(ll);
                ll = new LinearLayout(this);
                ll.setLayoutParams(new RadioGroup.LayoutParams(lp_wc, lp_wc, 1f));
                ll.setOrientation((rg.getOrientation() != ll_v) ? ll_v : ll_h);
                ll.setGravity(g_c);
            }
            RadioButton rb = RadioButton_Style(modos[i], modos[i]);
            rb.setOnClickListener(new View.OnClickListener() {
                String log_txt = "Modes", value_txt = "modo";

                public void onClick(View v) {
                    onClickValue(v, log_txt, value_txt);
                }
            });
            ll.addView(rb);
        }
        if (ll != null) rg.addView(ll);
    }

    public void onClickValue(View v, String log_txt, String value_txt) {
        Log.i(TAG, "onClick " + log_txt + "." + v.getTag() + ": " + v.getId() + " : " + ((RadioButton) v).getText());
        RadioGroup rg = (RadioGroup) v.getParent().getParent();
        for (int i = 0; i < rg.getChildCount(); i++) {
            LinearLayout ll = (LinearLayout) rg.getChildAt(i);
            for (int j = 0; j < ll.getChildCount(); j++) {
                if (ll.getChildAt(j) != v) ((RadioButton) ll.getChildAt(j)).setChecked(false);
            }
        }
        if (value_txt.equals("laberinto")) {
            if (v.getTag() != null) this.laberinto = (String) v.getTag();
            else this.laberinto = "";
        } else if (value_txt.equals("modo")) {
            if (v.getTag() != null) this.modo = (String) v.getTag();
            else this.modo = "";
        }
    }

    public void onPulsar(View v) {
        String nombre = ((EditText) findViewById(R.id.etNombre)).getText().toString().trim();
        if (nombre.equals("")) Utils.muestraMensaje(this, R.string.nombreInvalido);
        else if (this.laberinto.equals("")) Utils.muestraMensaje(this, R.string.laberintoInvalido);
//        else if (modo.equals("")){ Utils.muestraMensaje(this,R.string.modoInvalido); }
        else {
            /*witch (R.string) {}*/
            if (modo.equals(getString(R.string.modo_texto))) {
                startIntent(nombre, MazePlayerTextActivity.class, MAZE_PLAYER_TEXT_ACTIVITY_TAG);
            } else if (modo.equals(getString(R.string.modo_dibujo))) {
                startIntent(nombre, MazePlayerDrawActivity.class, MAZE_PLAYER_DRAW_ACTIVITY_TAG);
            } else Utils.muestraMensaje(this, R.string.modoInvalido);
        }
    }

    public void startIntent(String nombre, Class clase, int activityTag) {
        Intent intent = new Intent(this, clase);
        intent.putExtra("nombre", nombre);
        intent.putExtra("laberinto", this.laberinto);
        startActivityForResult(intent, activityTag);
    }

    /***********************************************************************************************/
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_settings: {
                return true;
            }
            case R.id.menu_ranking: {
                final View v = findViewById(R.id.menu_settings);/*item.getActionView()*/
                openPopup(v, R.id.menu_ranking);
                return true;
            }
            case R.id.menu_help: {
                final View v = findViewById(R.id.menu_settings);/*item.getActionView()*/
                openPopup(v, R.id.menu_help);
                return true;
            }
            case R.id.menu_info: {
                final View v = findViewById(R.id.menu_settings);/*item.getActionView()*/
                openPopup(v, R.id.menu_info);
                return true;
            }
            default: {
                return super.onOptionsItemSelected(item);
            }
        }
    }

    public void openPopup(View view) {
        Utils.openPopup(this, view, view.getId());
    }

    public void openPopup(View view, @IdRes int idPopup) {
        Utils.openPopup(this, view, idPopup);
    }

    /***********************************************************************************************/
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        /*String respuesta = data.getStringExtra("respuesta");*/
        /*if(resultCode==RESULT_FIRST_USER){}else if(resultCode==RESULT_OK){}else if(resultCode==RESULT_CANCELED){}*/
        Musica.release();/*actualizarBD((TextView) findViewById(R.id.tvGanardores));*/
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
}