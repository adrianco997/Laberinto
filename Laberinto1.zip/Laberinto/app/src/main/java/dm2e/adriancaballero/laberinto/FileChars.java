package dm2e.adriancaballero.laberinto;

import android.content.Context;
import android.content.res.Resources;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.annotation.DrawableRes;
import androidx.annotation.StringRes;

/**
 * Constantes publicas que definen los tipos de puntos que se permiten en un laberinto.</br>
 * Simbolos de entrada de fichero
 *
 * @author Adrian Caballeo Orasio
 */
public /* static */ enum FileChars {
    SPACE(' ', R.string.SPACE, R.drawable.space),
    BARRIER('+', R.string.BARRIER, R.drawable.barrier),
    INPUT('i', R.string.INPUT, R.drawable.input),
    OUTPUT('o', R.string.OUTPUT, R.drawable.output),
    ERRORCHAR('E', R.string.ERRORCHAR, 0/*R.drawable.errorchar*/),;
    public final char c;public final @StringRes int label;public final @DrawableRes int image;
    FileChars(char c, @StringRes int label, @DrawableRes int image) { this.c = c;this.label = label;this.image = image; }
    public static FileChars valueOf(char c) { for (FileChars m : values()) if (m.c == c) return m;return null; }
}
// typedef enum {RIGHT = 0, UP = 1, LEFT = 2, DOWN = 3, STAY = 4} Move;