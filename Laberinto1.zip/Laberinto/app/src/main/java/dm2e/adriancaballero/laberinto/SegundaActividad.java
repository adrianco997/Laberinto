package dm2e.adriancaballero.laberinto;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.annotation.RawRes;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

/**
 * @author Adrian Caballeo Orasio
 */
public class SegundaActividad extends AppCompatActivity {
    private final String TAG = getClass().getName();
    String laberintoType, name;
    static final int AUDIO_PATH_RAW1 = R.raw.misty_dungeon_short;
    private int moves = 0, /*iniWidth, iniHeight,*/
            cellsX = 19, cellsY = 8;
    private Point actual = null, input = null, output = null;
    private TextView tvLaberinto;
    boolean hasGanado = false;
    private Maze maze = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_actividad);

        tvLaberinto = findViewById(R.id.tvLaberinto);

        String nombre = "nombre", maze = "laberinto";
        if (getIntent() != null && getIntent().getStringExtra("nombre") != null) {
            if (!getIntent().getStringExtra(nombre).equals(""))
                this.name = getIntent().getStringExtra(nombre);
        } else this.name = "jugador";
        if (getIntent() != null && getIntent().getStringExtra("laberinto") != null) {
            if (!getIntent().getStringExtra(maze).equals(""))
                this.laberintoType = getIntent().getStringExtra(maze);
        } else this.laberintoType = "m1";

        ((TextView) findViewById(R.id.tv1)).setText(String.format(getResources().getString(R.string.ordenaLaberinto), name));
//        TextView tvC = findViewById(R.id.tvContador);tvC.setText(String.format(getResources().getString(R.string.movimientos), moves));


        //play(getResourceId(laberintoType, "raw"));
        ToggleButton toggle = (ToggleButton) findViewById(R.id.onOnOffMusica);
        toggle.setOnClickListener(new onClickMusica());
        musica(AUDIO_PATH_RAW1);
        onReset(null);
    }

    public void onReset(View v) {
        moves = 0;
        hasGanado = false;
        TextView tvC = findViewById(R.id.tvContador);
        tvC.setText(String.format(getResources().getString(R.string.movimientos), moves));
        ((TextView) findViewById(R.id.tvGanardores)).setText("");
        play(getResourceId(laberintoType, "raw"));
    }

    public void restart() {
        this.maze = null;
        this.input = null;
        this.output = null;
        this.actual = null;
        this.hasGanado = false;
    }

    public boolean play(@RawRes int idFile) {
        restart();
        this.maze = new Maze(this);
        if (!this.maze.read(idFile)) {
            Log.e(TAG, "Error en play.read");
            return false;
        }
        if (checkFile(idFile) != -1) {
//            muestraMensaje(getResources().getString(R.string.encontrada));
            if (this.input == null) this.input = maze.getInput();
            if (this.output == null) this.output = maze.getOutput();
            if (this.actual == null) this.actual = this.input;
            Log.i(TAG, "input: " + this.input + ", output: " + this.output + ", actual: " + this.actual);
            //if (maze.getNcols() < 19) cellsX = maze.getNcols();
            //if (maze.getNrows() < 8) cellsY = maze.getNrows();
            printMaze();
            return true;
        } else {
            muestraMensaje(getResources().getString(R.string.noEncontrada));
            return false;
        }
    }

    /****************************************************************/
    public int checkFile(@RawRes int mfile) {
        Movements[] strat = {Movements.LEFT, Movements.UP, Movements.RIGHT, Movements.DOWN,};
        //InputStream file = getResources().openRawResource(mfile);//File file = new File(mfile);
        Maze mazeAux = new Maze(this);
        int pathlength;
        if (!mazeAux.read(mfile)) {
            muestraMensaje("Error en recursiveSolver.");
            return -1;
        }
//		Log.i(TAG,("Mapa:\n" + mazeAux.toString()+"\nInput:  " + mazeAux.getInput()+"\nOutput: " + mazeAux.getOutput());
        pathlength = mazeAux.deepSearchStack(mazeAux.getInput(), strat);
//		pathlength = mazeAux.breadthSearchQueue(mazeAux.getInput(), strat);
//		pathlength = mazeAux.pathPaint(mazeAux.deepSearchRec(mazeAux.getInput(), strat, false))
        return pathlength;
    }

    private class onClickMusica implements View.OnClickListener {
        public void onClick(View v) {
            //findViewById(R.id.onOnOffMusica).setOnCheckedChangeListener();
            //ToggleButton toggle = (ToggleButton) v;//findViewById(R.id.togglebutton);
            ((ToggleButton) v).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        Musica.stop();
                    } // The toggle is enabled
                    else {
                        //Musica.start();
                        //Musica.reset();
                        musica(AUDIO_PATH_RAW1);
                    }// The toggle is disabled
                }
            });
        }
    }

    public void onBotonClick(View v) {
        if (!hasGanado) {
            Point neighbor;
            switch (v.getId()) {
                case R.id.up: {
                    neighbor = maze.getNeighbor(actual, Movements.UP);
                    break;
                }
                case R.id.down: {
                    neighbor = maze.getNeighbor(actual, Movements.DOWN);
                    break;
                }
                case R.id.left: {
                    neighbor = maze.getNeighbor(actual, Movements.LEFT);
                    break;
                }
                case R.id.right: {
                    neighbor = maze.getNeighbor(actual, Movements.RIGHT);
                    break;
                }
                default: {
                    throw new IllegalStateException("Unexpected value: " + v.getId());
                }
            }
            if (neighbor != null && !neighbor.isBarrier()) {
                if (!neighbor.isOutput()) {
                    if (!actual.isInput() && !actual.isOutput())
                        actual.setSymbol(FileChars.SPACE.c);
                    if (!neighbor.isInput()) neighbor.setSymbol(Movements.ACTUAL.c);
                } else actual.setSymbol(FileChars.SPACE.c);
                moves++;
                actual = neighbor;
            }
            printMaze();
            if (actual.equals(output)) {
                TextView tv = findViewById(R.id.tvContador);
                tv.setText(String.format(getResources().getString(R.string.movimientos), moves));
                muestraMensaje(String.format(getResources().getString(R.string.ganado), moves));
                onGanar();
            }
        } else onFinish(v);
    }

    public void printMaze() {
        TextView tv = findViewById(R.id.tvContador);
        tv.setText(String.format(getResources().getString(R.string.movimientos), moves));
        //tvLaberinto.setText(maze.toString());
        this.tvLaberinto.setText(this.maze.printMaze(this.actual, this.cellsX, this.cellsY));
    }

    protected void onGanar() {
        long id = 0;
        hasGanado = true;
        onPause();
        try {
            Ranking ranking = new Ranking(name, laberintoType, moves);
            SQLiteHelper_Ranking db = SQLiteHelper_Ranking.getInstance(this);
            id = db.addOrUpdateRanking(ranking);/*db.addRanking(ranking);*/
            actualizarBD();
        } catch (Exception e) {
            muestraMensaje("(" + id + ")" + e);
        }
        actualizarBD();
    }

    protected void actualizarBD() {
        tvLaberinto.setText("");
        String txt = "Rankings:\n";
        try {
            SQLiteHelper_Ranking db = SQLiteHelper_Ranking.getInstance(this);
            List<Ranking> ranking = db.getAllRankings();
            for (Ranking r : ranking) txt = String.format("%s%s\n", txt, r.toString(this));
            ((TextView) findViewById(R.id.tvGanardores)).setText(txt);
        } catch (Exception e) {
            muestraMensaje(getResources().getString(R.string.errorGanardores));
        }
    }

    public void onFinish(View v) {
        onPause();/*setResult(RESULT_OK, new Intent().putExtra("respuesta", String.format(getResources().getString(R.string.ganado), movimientos)));*/
        finish();
    }

    public int getResourceId(String name, String defType) {
        return getResources().getIdentifier(name, defType, getPackageName());
    }

    public void musica(int music) {
        try {
            Musica.musicaRaw(this, music);
            Musica.setLooping(true);
        } catch (IllegalArgumentException e) {
            Toast.makeText(getApplicationContext(), "" + e, Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    @Override
    public void onPause() {
        if (Musica.getMp() != null && Musica.getMp().isPlaying()) {
            Musica.onPause();
            Musica.retirar();
        }
        super.onPause();
    }

    protected void muestraMensaje(String txt) {
        Toast.makeText(this, txt, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
}

