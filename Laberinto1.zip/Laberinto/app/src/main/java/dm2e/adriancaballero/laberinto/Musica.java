package dm2e.adriancaballero.laberinto;

import android.Manifest;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.AudioRouting;
import android.media.DeniedByServerException;
import android.media.MediaDataSource;
import android.media.MediaDrm;
import android.media.MediaPlayer;
import android.media.MediaTimestamp;
import android.media.PlaybackParams;
import android.media.ResourceBusyException;
import android.media.SyncParams;
import android.media.UnsupportedSchemeException;
import android.media.VolumeShaper;
import android.media.audiofx.AudioEffect;
import android.media.audiofx.EnvironmentalReverb;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.PersistableBundle;
import android.os.PowerManager;
import android.view.Surface;
import android.view.SurfaceHolder;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import java.io.FileDescriptor;
import java.io.IOException;
import java.net.HttpCookie;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author Adrian Caballeo Orasio
 */
public class Musica {
    private static MediaPlayer mp;

    public static MediaPlayer getMp() {
        return mp;
    }

    public static void setMediaPlayer() {
        mp = (mp == null) ? new MediaPlayer() : mp;
    }

    //Musica.musicaRaw(this, music);
    public static synchronized void musicaRaw(Context contexto, int id) throws IllegalArgumentException {
        setMediaPlayer();
        mp = MediaPlayer.create(contexto.getApplicationContext(), id);
        mp.start();
    }

    // public static synchronized void musicaSD(Context contexto, String pathSD) throws IllegalArgumentException, IOException { android.net.Uri datos = Uri.parse(Environment.getExternalStorageDirectory().getPath() + pathSD);setMediaPlayer();mp.setAudioStreamType(AudioManager.STREAM_MUSIC);mp.setDataSource(contexto.getApplicationContext(), datos);/* mp = MediaPlayer.create(contexto.getApplicationContext(), datos);*/mp.prepare();mp.start(); }
    // public static synchronized void musicaHTTP(String url) throws IllegalArgumentException, IOException { setMediaPlayer();mp.setAudioStreamType(AudioManager.STREAM_MUSIC);mp.setDataSource(url);mp.prepare();mp.start(); }
    // public static synchronized void musicaAssets(Context contexto, String asset) throws IllegalArgumentException, IOException { AssetFileDescriptor afd = contexto.getApplicationContext().getAssets().openFd(asset);setMediaPlayer();mp.reset();mp.setDataSource(afd.getFileDescriptor());mp.prepare();mp.start(); }

    public static void onPause() {
        if (mp != null && mp.isPlaying()) {
            mp.stop();
        }/*super.onPause();*/
    }

    public static void retirar() {
        if (mp != null) {
            mp.release();
            mp = null;
        }
    }


    /**
     * Convenience method to create a MediaPlayer for a given Uri.
     * On success, {@link #prepare()} will already have been called and must not be called again.
     * <p>When done with the MediaPlayer, you should call  {@link #release()},
     * to free the resources. If not released, too many MediaPlayer instances will
     * result in an exception.</p>
     * <p>Note that since {@link #prepare()} is called automatically in this method,
     * you cannot change the audio
     * session ID (see {@link #setAudioSessionId(int)}) or audio attributes
     * (see {@link #setAudioAttributes(AudioAttributes)} of the new MediaPlayer.</p>
     *
     * @param context the Context to use
     * @param uri     the Uri from which to get the datasource
     * @return a MediaPlayer object, or null if creation failed
     */
    public static MediaPlayer create(Context context, Uri uri) {
        return MediaPlayer.create(context, uri);
    }

    /**
     * Convenience method to create a MediaPlayer for a given Uri.
     * On success, {@link #prepare()} will already have been called and must not be called again.
     * <p>When done with the MediaPlayer, you should call  {@link #release()},
     * to free the resources. If not released, too many MediaPlayer instances will
     * result in an exception.</p>
     * <p>Note that since {@link #prepare()} is called automatically in this method,
     * you cannot change the audio
     * session ID (see {@link #setAudioSessionId(int)}) or audio attributes
     * (see {@link #setAudioAttributes(AudioAttributes)} of the new MediaPlayer.</p>
     *
     * @param context the Context to use
     * @param uri     the Uri from which to get the datasource
     * @param holder  the SurfaceHolder to use for displaying the video
     * @return a MediaPlayer object, or null if creation failed
     */
    public static MediaPlayer create(Context context, Uri uri, SurfaceHolder holder) {
        return MediaPlayer.create(context, uri, holder);
    }

    /**
     * Convenience method to create a MediaPlayer for a given resource id.
     * On success, {@link #prepare()} will already have been called and must not be called again.
     * <p>When done with the MediaPlayer, you should call  {@link #release()},
     * to free the resources. If not released, too many MediaPlayer instances will
     * result in an exception.</p>
     * <p>Note that since {@link #prepare()} is called automatically in this method,
     * you cannot change the audio
     * session ID (see {@link #setAudioSessionId(int)}) or audio attributes
     * (see {@link #setAudioAttributes(AudioAttributes)} of the new MediaPlayer.</p>
     *
     * @param context the Context to use
     * @param resid   the raw resource id (<var>R.raw.&lt;something></var>) for
     *                the resource to use as the datasource
     * @return a MediaPlayer object, or null if creation failed
     */
    public static MediaPlayer create(Context context, int resid) {
        return MediaPlayer.create(context, resid);
    }

    /**
     * Sets the data source as a content Uri.
     *
     * @param context the Context to use when resolving the Uri
     * @param uri     the Content URI of the data you want to play
     * @throws IllegalStateException if it is called in an invalid state
     */
    public static void setDataSource(@NonNull Context context, @NonNull Uri uri) throws IOException, IllegalArgumentException, IllegalStateException, SecurityException {
        mp.setDataSource(context, uri);
    }

    /**
     * Sets the data source as a content Uri.
     * <p>
     * To provide cookies for the subsequent HTTP requests, you can install your own default cookie
     * handler and use other variants of setDataSource APIs instead. Alternatively, you can use
     * this API to pass the cookies as a list of HttpCookie. If the app has not installed
     * a CookieHandler already, this API creates a CookieManager and populates its CookieStore with
     * the provided cookies. If the app has installed its own handler already, this API requires the
     * handler to be of CookieManager type such that the API can update the manager’s CookieStore.
     *
     * <p><strong>Note</strong> that the cross domain redirection is allowed by default,
     * but that can be changed with key/value pairs through the headers parameter with
     * "android-allow-cross-domain-redirect" as the key and "0" or "1" as the value to
     * disallow or allow cross domain redirection.
     *
     * @param context the Context to use when resolving the Uri
     * @param uri     the Content URI of the data you want to play
     * @param headers the headers to be sent together with the request for the data
     *                The headers must not include cookies. Instead, use the cookies param.
     * @param cookies the cookies to be sent together with the request
     * @throws IllegalArgumentException if cookies are provided and the installed handler is not
     *                                  a CookieManager
     * @throws IllegalStateException    if it is called in an invalid state
     * @throws NullPointerException     if context or uri is null
     * @throws IOException              if uri has a file scheme and an I/O error occurs
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static void setDataSource(@NonNull Context context, @NonNull Uri uri, @Nullable Map<String, String> headers, @Nullable List<HttpCookie> cookies) throws IOException {
        mp.setDataSource(context, uri, headers, cookies);
    }

    /**
     * Sets the data source as a content Uri.
     *
     * <p><strong>Note</strong> that the cross domain redirection is allowed by default,
     * but that can be changed with key/value pairs through the headers parameter with
     * "android-allow-cross-domain-redirect" as the key and "0" or "1" as the value to
     * disallow or allow cross domain redirection.
     *
     * @param context the Context to use when resolving the Uri
     * @param uri     the Content URI of the data you want to play
     * @param headers the headers to be sent together with the request for the data
     * @throws IllegalStateException if it is called in an invalid state
     */
    public static void setDataSource(@NonNull Context context, @NonNull Uri uri, @Nullable Map<String, String> headers) throws IOException, IllegalArgumentException, IllegalStateException, SecurityException {
        mp.setDataSource(context, uri, headers);
    }

    /**
     * Sets the data source (file-path or http/rtsp URL) to use.
     *
     * <p>When <code>path</code> refers to a local file, the file may actually be opened by a
     * process other than the calling application.  This implies that the pathname
     * should be an absolute path (as any other process runs with unspecified current working
     * directory), and that the pathname should reference a world-readable file.
     * As an alternative, the application could first open the file for reading,
     * and then use the file descriptor form {@link #setDataSource(FileDescriptor)}.
     *
     * @param path the path of the file, or the http/rtsp URL of the stream you want to play
     * @throws IllegalStateException if it is called in an invalid state
     */
    public static void setDataSource(String path) throws IOException, IllegalArgumentException, IllegalStateException, SecurityException {
        mp.setDataSource(path);
    }

    /**
     * Sets the data source (AssetFileDescriptor) to use. It is the caller's
     * responsibility to close the file descriptor. It is safe to do so as soon
     * as this call returns.
     *
     * @param afd the AssetFileDescriptor for the file you want to play
     * @throws IllegalStateException    if it is called in an invalid state
     * @throws IllegalArgumentException if afd is not a valid AssetFileDescriptor
     * @throws IOException              if afd can not be read
     */
    @RequiresApi(api = Build.VERSION_CODES.N)
    public static void setDataSource(@NonNull AssetFileDescriptor afd) throws IOException, IllegalArgumentException, IllegalStateException {
        mp.setDataSource(afd);
    }

    /**
     * Sets the data source (FileDescriptor) to use. It is the caller's responsibility
     * to close the file descriptor. It is safe to do so as soon as this call returns.
     *
     * @param fd the FileDescriptor for the file you want to play
     * @throws IllegalStateException    if it is called in an invalid state
     * @throws IllegalArgumentException if fd is not a valid FileDescriptor
     * @throws IOException              if fd can not be read
     */
    public static void setDataSource(FileDescriptor fd) throws IOException, IllegalArgumentException, IllegalStateException {
        mp.setDataSource(fd);
    }

    /**
     * Sets the data source (FileDescriptor) to use.  The FileDescriptor must be
     * seekable (N.B. a LocalSocket is not seekable). It is the caller's responsibility
     * to close the file descriptor. It is safe to do so as soon as this call returns.
     *
     * @param fd     the FileDescriptor for the file you want to play
     * @param offset the offset into the file where the data to be played starts, in bytes
     * @param length the length in bytes of the data to be played
     * @throws IllegalStateException    if it is called in an invalid state
     * @throws IllegalArgumentException if fd is not a valid FileDescriptor
     * @throws IOException              if fd can not be read
     */
    public static void setDataSource(FileDescriptor fd, long offset, long length) throws IOException, IllegalArgumentException, IllegalStateException {
        mp.setDataSource(fd, offset, length);
    }

    /**
     * Sets the data source (MediaDataSource) to use.
     *
     * @param dataSource the MediaDataSource for the media you want to play
     * @throws IllegalStateException    if it is called in an invalid state
     * @throws IllegalArgumentException if dataSource is not a valid MediaDataSource
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    public static void setDataSource(MediaDataSource dataSource) throws IllegalArgumentException, IllegalStateException {
        mp.setDataSource(dataSource);
    }

    /**
     * Prepares the player for playback, synchronously.
     * <p>
     * After setting the datasource and the display surface, you need to either
     * call prepare() or prepareAsync(). For files, it is OK to call prepare(),
     * which blocks until MediaPlayer is ready for playback.
     *
     * @throws IllegalStateException if it is called in an invalid state
     */
    public static void prepare() throws IOException, IllegalStateException {
        mp.prepare();
    }

    /**
     * Prepares the player for playback, asynchronously.
     * <p>
     * After setting the datasource and the display surface, you need to either
     * call prepare() or prepareAsync(). For streams, you should call prepareAsync(),
     * which returns immediately, rather than blocking until enough data has been
     * buffered.
     *
     * @throws IllegalStateException if it is called in an invalid state
     */
    public static void prepareAsync() throws IllegalStateException {
        mp.prepareAsync();
    }

    /**
     * Starts or resumes playback. If playback had previously been paused,
     * playback will continue from where it was paused. If playback had
     * been stopped, or never started before, playback will start at the
     * beginning.
     *
     * @throws IllegalStateException if it is called in an invalid state
     */
    public static void start() throws IllegalStateException {
        mp.start();
    }

    /**
     * Stops playback after playback has been started or paused.
     *
     * @throws IllegalStateException if the internal player engine has not been
     *                               initialized.
     */
    public static void stop() throws IllegalStateException {
        mp.stop();
    }

    /**
     * Pauses playback. Call start() to resume.
     *
     * @throws IllegalStateException if the internal player engine has not been
     *                               initialized.
     */
    public static void pause() throws IllegalStateException {
        mp.pause();
    }

    /**
     * Checks whether the MediaPlayer is playing.
     *
     * @return true if currently playing, false otherwise
     * @throws IllegalStateException if the internal player engine has not been
     *                               initialized or has been released.
     */
    public static boolean isPlaying() {
        return mp.isPlaying();
    }


    /**
     * Gets the playback params, containing the current playback rate.
     *
     * @return the playback params.
     * @throws IllegalStateException if the internal player engine has not been
     *                               initialized.
     */
    @NonNull
    @RequiresApi(api = Build.VERSION_CODES.M)
    public static PlaybackParams getPlaybackParams() {
        return mp.getPlaybackParams();
    }


    /**
     * Moves the media to specified time position by considering the given mode.
     * <p>
     * When seekTo is finished, the user will be notified via OnSeekComplete supplied by the user.
     * There is at most one active seekTo processed at any time. If there is a to-be-completed
     * seekTo, new seekTo requests will be queued in such a way that only the last request
     * is kept. When current seekTo is completed, the queued request will be processed if
     * that request is different from just-finished seekTo operation, i.e., the requested
     * position or mode is different.
     *
     * @param msec the offset in milliseconds from the start to seek to.
     *             When seeking to the given time position, there is no guarantee that the data source
     *             has a frame located at the position. When this happens, a frame nearby will be rendered.
     *             If msec is negative, time position zero will be used.
     *             If msec is larger than duration, duration will be used.
     * @param mode the mode indicating where exactly to seek to.
     *             Use {SEEK_PREVIOUS_SYNC} if one wants to seek to a sync frame
     *             that has a timestamp earlier than or the same as msec. Use
     *             {SEEK_NEXT_SYNC} if one wants to seek to a sync frame
     *             that has a timestamp later than or the same as msec. Use
     *             {SEEK_CLOSEST_SYNC} if one wants to seek to a sync frame
     *             that has a timestamp closest to or the same as msec. Use
     *             {SEEK_CLOSEST} if one wants to seek to a frame that may
     *             or may not be a sync frame but is closest to or the same as msec.
     *             {SEEK_CLOSEST} often has larger performance overhead compared
     *             to the other options if there is no sync frame located at msec.
     * @throws IllegalStateException    if the internal player engine has not been
     *                                  initialized
     * @throws IllegalArgumentException if the mode is invalid.
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static void seekTo(long msec, int mode) {
        mp.seekTo(msec, mode);
    }

    /**
     * Seeks to specified time position.
     * Same as {@link #seekTo(long, int)} with {@code mode = SEEK_PREVIOUS_SYNC}.
     *
     * @param msec the offset in milliseconds from the start to seek to
     * @throws IllegalStateException if the internal player engine has not been
     *                               initialized
     */
    public static void seekTo(int msec) throws IllegalStateException {
        mp.seekTo(msec);
    }

    /**
     * Get current playback position as a {@link MediaTimestamp}.
     * <p>
     * The MediaTimestamp represents how the media time correlates to the system time in
     * a linear fashion using an anchor and a clock rate. During regular playback, the media
     * time moves fairly constantly (though the anchor frame may be rebased to a current
     * system time, the linear correlation stays steady). Therefore, this method does not
     * need to be called often.
     * <p>
     * To help users get current playback position, this method always anchors the timestamp
     * to the current {@link System#nanoTime system time}, so
     * {@link MediaTimestamp#getAnchorMediaTimeUs} can be used as current playback position.
     *
     * @return a MediaTimestamp object if a timestamp is available, or {@code null} if no timestamp
     * is available, e.g. because the media player has not been initialized.
     * @see MediaTimestamp
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Nullable
    public static MediaTimestamp getTimestamp() {
        return mp.getTimestamp();
    }

    /**
     * Gets the current playback position.
     *
     * @return the current position in milliseconds
     */
    public static int getCurrentPosition() {
        return mp.getCurrentPosition();
    }

    /**
     * Gets the duration of the file.
     *
     * @return the duration in milliseconds, if no duration is available
     * (for example, if streaming live content), -1 is returned.
     */
    public static int getDuration() {
        return mp.getDuration();
    }

    /**
     * Set the MediaPlayer to start when this MediaPlayer finishes playback
     * (i.e. reaches the end of the stream).
     * The media framework will attempt to transition from this player to
     * the next as seamlessly as possible. The next player can be set at
     * any time before completion, but shall be after setDataSource has been
     * called successfully. The next player must be prepared by the
     * app, and the application should not call start() on it.
     * The next MediaPlayer must be different from 'this'. An exception
     * will be thrown if next == this.
     * The application may call setNextMediaPlayer(null) to indicate no
     * next player should be started at the end of playback.
     * If the current player is looping, it will keep looping and the next
     * player will not be started.
     *
     * @param next the player to start after this one completes playback.
     */
    public static void setNextMediaPlayer(MediaPlayer next) {
        mp.setNextMediaPlayer(next);
    }

    /**
     * Releases resources associated with this MediaPlayer object.
     * It is considered good practice to call this method when you're
     * done using the MediaPlayer. In particular, whenever an Activity
     * of an application is paused (its onPause() method is called),
     * or stopped (its onStop() method is called), this method should be
     * invoked to release the MediaPlayer object, unless the application
     * has a special need to keep the object around. In addition to
     * unnecessary resources (such as memory and instances of codecs)
     * being held, failure to call this method immediately if a
     * MediaPlayer object is no longer needed may also lead to
     * continuous battery consumption for mobile devices, and playback
     * failure for other applications if no multiple instances of the
     * same codec are supported on a device. Even if multiple instances
     * of the same codec are supported, some performance degradation
     * may be expected when unnecessary multiple instances are used
     * at the same time.
     */
    public static void release() {
        mp.release();
    }

    /**
     * Resets the MediaPlayer to its uninitialized state. After calling
     * this method, you will have to initialize it again by setting the
     * data source and calling prepare().
     */
    public static void reset() {
        mp.reset();
    }

    /**
     * Sets the audio stream type for this MediaPlayer. See {@link AudioManager}
     * for a list of stream types. Must call this method before prepare() or
     * prepareAsync() in order for the target stream type to become effective
     * thereafter.
     *
     * @param streamtype the audio stream type
     * @see AudioManager
     * @deprecated use {@link #setAudioAttributes(AudioAttributes)}
     */
    @Deprecated
    public static void setAudioStreamType(int streamtype) {
        mp.setAudioStreamType(streamtype);
    }

    /**
     * Sets the audio attributes for this MediaPlayer.
     * See {@link AudioAttributes} for how to build and configure an instance of this class.
     * You must call this method before {@link #prepare()} or {@link #prepareAsync()} in order
     * for the audio attributes to become effective thereafter.
     *
     * @param attributes a non-null set of audio attributes
     */
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static void setAudioAttributes(AudioAttributes attributes) throws IllegalArgumentException {
        mp.setAudioAttributes(attributes);
    }

    /**
     * Sets the player to be looping or non-looping.
     *
     * @param looping whether to loop or not
     */
    public static void setLooping(boolean looping) {
        mp.setLooping(looping);
    }

    /**
     * Checks whether the MediaPlayer is looping or non-looping.
     *
     * @return true if the MediaPlayer is currently looping, false otherwise
     */
    public static boolean isLooping() {
        return mp.isLooping();
    }

    /**
     * Sets the volume on this player.
     * This API is recommended for balancing the output of audio streams
     * within an application. Unless you are writing an application to
     * control user settings, this API should be used in preference to
     * {@link AudioManager#setStreamVolume(int, int, int)} which sets the volume of ALL streams of
     * a particular type. Note that the passed volume values are raw scalars in range 0.0 to 1.0.
     * UI controls should be scaled logarithmically.
     *
     * @param leftVolume  left volume scalar
     * @param rightVolume right volume scalar
     */
    public static void setVolume(float leftVolume, float rightVolume) {
        mp.setVolume(leftVolume, rightVolume);
    }

    /**
     * Sets the audio session ID.
     *
     * @param sessionId the audio session ID.
     *                  The audio session ID is a system wide unique identifier for the audio stream played by
     *                  this MediaPlayer instance.
     *                  The primary use of the audio session ID  is to associate audio effects to a particular
     *                  instance of MediaPlayer: if an audio session ID is provided when creating an audio effect,
     *                  this effect will be applied only to the audio content of media players within the same
     *                  audio session and not to the output mix.
     *                  When created, a MediaPlayer instance automatically generates its own audio session ID.
     *                  However, it is possible to force this player to be part of an already existing audio session
     *                  by calling this method.
     *                  This method must be called before one of the overloaded <code> setDataSource </code> methods.
     * @throws IllegalStateException if it is called in an invalid state
     */
    public static void setAudioSessionId(int sessionId) throws IllegalArgumentException, IllegalStateException {
        mp.setAudioSessionId(sessionId);
    }

    /**
     * Returns the audio session ID.
     *
     * @return the audio session ID. {@see #setAudioSessionId(int)}
     * Note that the audio session ID is 0 only if a problem occured when the MediaPlayer was contructed.
     */
    public static int getAudioSessionId() {
        return mp.getAudioSessionId();
    }



    /**
     * Prepares the DRM for the current source
     * <p>
     * If {@code OnDrmConfigHelper} is registered, it will be called during
     * preparation to allow configuration of the DRM properties before opening the
     * DRM session. Note that the callback is called synchronously in the thread that called
     * {@code prepareDrm}. It should be used only for a series of {@code getDrmPropertyString}
     * and {@code setDrmPropertyString} calls and refrain from any lengthy operation.
     * <p>
     * If the device has not been provisioned before, this call also provisions the device
     * which involves accessing the provisioning server and can take a variable time to
     * complete depending on the network connectivity.
     * If {@code OnDrmPreparedListener} is registered, prepareDrm() runs in non-blocking
     * mode by launching the provisioning in the background and returning. The listener
     * will be called when provisioning and preparation has finished. If a
     * {@code OnDrmPreparedListener} is not registered, prepareDrm() waits till provisioning
     * and preparation has finished, i.e., runs in blocking mode.
     * <p>
     * If {@code OnDrmPreparedListener} is registered, it is called to indicate the DRM
     * session being ready. The application should not make any assumption about its call
     * sequence (e.g., before or after prepareDrm returns), or the thread context that will
     * execute the listener (unless the listener is registered with a handler thread).
     * <p>
     *
     * @param uuid The UUID of the crypto scheme. If not known beforehand, it can be retrieved
     *             from the source through {@code getDrmInfo} or registering a {@code onDrmInfoListener}.
     * @throws IllegalStateException             if called before prepare(), or the DRM was
     *                                           prepared already
     * @throws UnsupportedSchemeException        if the crypto scheme is not supported
     * @throws ResourceBusyException             if required DRM resources are in use
     * @throws MediaPlayer.ProvisioningNetworkErrorException if provisioning is required but failed due to a
     *                                           network error
     * @throws MediaPlayer.ProvisioningServerErrorException  if provisioning is required but failed due to
     *                                           the request denied by the provisioning server
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static void prepareDrm(@NonNull UUID uuid) throws MediaPlayer.ProvisioningNetworkErrorException, MediaPlayer.ProvisioningServerErrorException, ResourceBusyException, UnsupportedSchemeException {
        mp.prepareDrm(uuid);
    }

    /**
     * Releases the DRM session
     * <p>
     * The player has to have an active DRM session and be in stopped, or prepared
     * state before this call is made.
     * A {@code reset()} call will release the DRM session implicitly.
     *
     * @throws MediaPlayer.NoDrmSchemeException if there is no active DRM session to release
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static void releaseDrm() throws MediaPlayer.NoDrmSchemeException {
        mp.releaseDrm();
    }

    /**
     * A key request/response exchange occurs between the app and a license server
     * to obtain or release keys used to decrypt encrypted content.
     * <p>
     * getKeyRequest() is used to obtain an opaque key request byte array that is
     * delivered to the license server.  The opaque key request byte array is returned
     * in KeyRequest.data.  The recommended URL to deliver the key request to is
     * returned in KeyRequest.defaultUrl.
     * <p>
     * After the app has received the key request response from the server,
     * it should deliver to the response to the DRM engine plugin using the method
     * {@link #provideKeyResponse}.
     *
     * @param keySetId           is the key-set identifier of the offline keys being released when keyType is
     *                           {@link MediaDrm#KEY_TYPE_RELEASE}. It should be set to null for other key requests, when
     *                           keyType is {@link MediaDrm#KEY_TYPE_STREAMING} or {@link MediaDrm#KEY_TYPE_OFFLINE}.
     * @param initData           is the container-specific initialization data when the keyType is
     *                           {@link MediaDrm#KEY_TYPE_STREAMING} or {@link MediaDrm#KEY_TYPE_OFFLINE}. Its meaning is
     *                           interpreted based on the mime type provided in the mimeType parameter.  It could
     *                           contain, for example, the content ID, key ID or other data obtained from the content
     *                           metadata that is required in generating the key request.
     *                           When the keyType is {@link MediaDrm#KEY_TYPE_RELEASE}, it should be set to null.
     * @param mimeType           identifies the mime type of the content
     * @param keyType            specifies the type of the request. The request may be to acquire
     *                           keys for streaming, {@link MediaDrm#KEY_TYPE_STREAMING}, or for offline content
     *                           {@link MediaDrm#KEY_TYPE_OFFLINE}, or to release previously acquired
     *                           keys ({@link MediaDrm#KEY_TYPE_RELEASE}), which are identified by a keySetId.
     * @param optionalParameters are included in the key request message to
     *                           allow a client application to provide additional message parameters to the server.
     *                           This may be {@code null} if no additional parameters are to be sent.
     * @throws MediaPlayer.NoDrmSchemeException if there is no active DRM session
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @NonNull
    public static MediaDrm.KeyRequest getKeyRequest(@Nullable byte[] keySetId, @Nullable byte[] initData, @Nullable String mimeType, int keyType, @Nullable Map<String, String> optionalParameters) throws MediaPlayer.NoDrmSchemeException {
        return mp.getKeyRequest(keySetId, initData, mimeType, keyType, optionalParameters);
    }

    /**
     * A key response is received from the license server by the app, then it is
     * provided to the DRM engine plugin using provideKeyResponse. When the
     * response is for an offline key request, a key-set identifier is returned that
     * can be used to later restore the keys to a new session with the method
     * {link # restoreKeys}.
     * When the response is for a streaming or release request, null is returned.
     *
     * @param keySetId When the response is for a release request, keySetId identifies
     *                 the saved key associated with the release request (i.e., the same keySetId
     *                 passed to the earlier {link # getKeyRequest} call. It MUST be null when the
     *                 response is for either streaming or offline key requests.
     * @param response the byte array response from the server
     * @param keySetId aaa sd
     * @param response aaaa
     * @throws MediaPlayer.NoDrmSchemeException if there is no active DRM session
     * @throws DeniedByServerException          if the response indicates that the
     *                                          server rejected the request
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static byte[] provideKeyResponse(@Nullable byte[] keySetId, @NonNull byte[] response) throws DeniedByServerException, MediaPlayer.NoDrmSchemeException {
        return mp.provideKeyResponse(keySetId, response);
    }

    /**
     * Restore persisted offline keys into a new session.  keySetId identifies the
     * keys to load, obtained from a prior call to {@link #provideKeyResponse}.
     *
     * @param keySetId identifies the saved key set to restore
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static void restoreKeys(@NonNull byte[] keySetId) throws MediaPlayer.NoDrmSchemeException {
        mp.restoreKeys(keySetId);
    }

}
