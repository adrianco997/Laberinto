package dm2e.laberinto;

import android.Manifest;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.AudioRouting;
import android.media.DeniedByServerException;
import android.media.MediaDataSource;
import android.media.MediaDrm;
import android.media.MediaPlayer;
import android.media.MediaTimestamp;
import android.media.PlaybackParams;
import android.media.ResourceBusyException;
import android.media.SyncParams;
import android.media.UnsupportedSchemeException;
import android.media.VolumeShaper;
import android.media.audiofx.AudioEffect;
import android.media.audiofx.EnvironmentalReverb;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.PersistableBundle;
import android.os.PowerManager;
import android.view.Surface;
import android.view.SurfaceHolder;

import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RawRes;
import androidx.annotation.RequiresApi;

import java.io.FileDescriptor;
import java.io.IOException;
import java.net.HttpCookie;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author Adrian Caballeo Orasio
 */
public class Musica {
    private static MediaPlayer mp;
    private static boolean is_muted = false;
    //private static boolean is_playing = false;
    @RawRes
    static final int AUDIO_PATH_RAW = R.raw.misty_dungeon_short;

    public static MediaPlayer getMp() {
        return mp;
    }

    public static boolean isIsMuted() { return is_muted; }
    //public static boolean isIsPlaying() { return isPlaying; }
    //public static void setIsMuted(boolean isMuted) { Musica.isMuted = isMuted; }
    //public static void setIsPlaying(boolean isPlaying) { Musica.isPlaying = isPlaying; }


    public static void setMediaPlayer() {
        mp = (mp == null) ? new MediaPlayer() : mp;
    }

    //Musica.musicaRaw(this, music);
    public static synchronized void creator(Context contexto, int n_audio) throws IllegalArgumentException {
        //setMediaPlayer();
        //mp = MediaPlayer.create(contexto.getApplicationContext(), id);
        if (mp == null) mp = create(contexto.getApplicationContext(), AUDIO_PATH_RAW);
        //start();
        mp.setLooping(true);
    }

    public static void mute() {
        if (mp != null) {
            if (!is_muted) {
                mp.setVolume(0, 0);
                is_muted = true;
            } else {
                mp.setVolume(1, 1);
                is_muted = false;
            }
        }
    }

    /**
     * Convenience method to create a MediaPlayer for a given resource id.
     * On success, {@link #prepare()} will already have been called and must not be called again.
     * <p>When done with the MediaPlayer, you should call {@link #release()}, to free the resources.
     * If not released, too many MediaPlayer instances will result in an exception.</p>
     * <p>Note that since {@link #prepare()} is called automatically in this method,
     * you cannot change the audio session ID (see {setAudioSessionId(int)}) or audio attributes
     * (see {setAudioAttributes(AudioAttributes)} of the new MediaPlayer.</p>
     *
     * @param context the Context to use
     * @param resid   the raw resource id (<var>R.raw.&lt;something></var>) for
     *                the resource to use as the datasource
     * @return a MediaPlayer object, or null if creation failed
     */
    public static MediaPlayer create(Context context, int resid) {
        return MediaPlayer.create(context, resid);
    }

    /**
     * Prepares the player for playback, synchronously.
     * <p>
     * After setting the datasource and the display surface, you need to either
     * call prepare() or prepareAsync(). For files, it is OK to call prepare(),
     * which blocks until MediaPlayer is ready for playback.
     *
     * @throws IllegalStateException if it is called in an invalid state
     */
    public static void prepare() throws IOException, IllegalStateException {
        mp.prepare();
    }

    /**
     * Starts or resumes playback. If playback had previously been paused,
     * playback will continue from where it was paused. If playback had
     * been stopped, or never started before, playback will start at the
     * beginning.
     *
     * @throws IllegalStateException if it is called in an invalid state
     */
    public static void start() throws IllegalStateException {
        if (!is_muted) mp.start();
    }

    /**
     * Stops playback after playback has been started or paused.
     *
     * @throws IllegalStateException if the internal player engine has not been
     *                               initialized.
     */
    public static void stop() throws IllegalStateException {
        //if (mp != null && mp.isPlaying())
            mp.stop();
        ///*super.onPause();*/
    }

    /**
     * Pauses playback. Call start() to resume.
     *
     * @throws IllegalStateException if the internal player engine has not been
     *                               initialized.
     */
    public static void pause() throws IllegalStateException {
        mp.pause();
    }

    /**
     * Checks whether the MediaPlayer is playing.
     *
     * @return true if currently playing, false otherwise
     * @throws IllegalStateException if the internal player engine has not been
     *                               initialized or has been released.
     */
    public static boolean isPlaying() /*throws IllegalStateException*/ {
        try {
            if (mp != null) return mp.isPlaying();
            else return false;
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
        return false;
    }











    /**
     * Gets the current playback position.
     *
     * @return the current position in milliseconds
     */
    public static int getCurrentPosition() {
        return mp.getCurrentPosition();
    }

    /**
     * Gets the duration of the file.
     *
     * @return the duration in milliseconds, if no duration is available
     * (for example, if streaming live content), -1 is returned.
     */
    public static int getDuration() {
        return mp.getDuration();
    }

    /**
     * Releases resources associated with this MediaPlayer object.
     * It is considered good practice to call this method when you're
     * done using the MediaPlayer. In particular, whenever an Activity
     * of an application is paused (its onPause() method is called),
     * or stopped (its onStop() method is called), this method should be
     * invoked to release the MediaPlayer object, unless the application
     * has a special need to keep the object around. In addition to
     * unnecessary resources (such as memory and instances of codecs)
     * being held, failure to call this method immediately if a
     * MediaPlayer object is no longer needed may also lead to
     * continuous battery consumption for mobile devices, and playback
     * failure for other applications if no multiple instances of the
     * same codec are supported on a device. Even if multiple instances
     * of the same codec are supported, some performance degradation
     * may be expected when unnecessary multiple instances are used
     * at the same time.
     */
    public static void release() {
        if (mp != null) {
            mp.release();
            mp = null;
        }
    }

    /**
     * Resets the MediaPlayer to its uninitialized state. After calling
     * this method, you will have to initialize it again by setting the
     * data source and calling prepare().
     */
    public static void reset() {
        if (mp != null) {mp.reset();}
    }

}
