package dm2e.laberinto;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.annotation.RawRes;
import androidx.appcompat.app.AppCompatActivity;

/**
 * @author Adrian Caballero Orasio
 * @author Carlos del Valle Pelaez
 */
public class MazePlayerDrawActivity extends AppCompatActivity {
    private final String TAG = getClass().getName();
    private final static String STATE_moves = "moves";
    private final static String STATE_cells = "cells";
    private final static String STATE_hasGanado = "hasGanado";
    private final static String STATE_actualX = "actualX";
    private final static String STATE_actualY = "actualY";
    private final static String STATE_actualSymbol = "actualSymbol";
    private String laberintoType = "error";
    private String nombreJugador = "";
    private MazeView mazeViewer = null;
    private TextView tvContador = null;
    private boolean hasGanado = false;
    private Point actual = null;
    private Point input = null;
    private Point output = null;
    private Maze maze = null;
    private int moves = 0;
    private int cells;

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outInstance) {
        super.onSaveInstanceState(outInstance);
        android.util.Log.e(TAG, "onSaveInstanceState");
        outInstance.putInt(STATE_moves, moves);
        outInstance.putInt(STATE_cells, cells);
        outInstance.putBoolean(STATE_hasGanado, hasGanado);
        outInstance.putInt(STATE_actualX, actual.getX());
        outInstance.putInt(STATE_actualY, actual.getY());
        outInstance.putChar(STATE_actualSymbol, actual.getSymbol());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mazeplayer_draw);
        this.mazeViewer = findViewById(R.id.MazeView);
        this.mazeViewer.setScaleType(ImageView.ScaleType.MATRIX);
        String[] intent = Utils.getIntentInfo(getIntent());
        this.nombreJugador = intent[0];
        this.laberintoType = intent[1];
        this.tvContador = findViewById(R.id.tvContador);
        findViewById(R.id.up).setOnClickListener(new DpadClick());
        findViewById(R.id.down).setOnClickListener(new DpadClick());
        findViewById(R.id.left).setOnClickListener(new DpadClick());
        findViewById(R.id.right).setOnClickListener(new DpadClick());
        if (savedInstanceState != null) {
            android.util.Log.e(TAG, "onSaveInstanceState != null");
            moves = savedInstanceState.getInt(STATE_moves);
            cells = savedInstanceState.getInt(STATE_cells);
            hasGanado = savedInstanceState.getBoolean(STATE_hasGanado);
            actual = new Point(savedInstanceState.getInt(STATE_actualX),
                    savedInstanceState.getInt(STATE_actualY),
                    savedInstanceState.getChar(STATE_actualSymbol));
            android.util.Log.e(TAG, "moves = " + moves);
            android.util.Log.e(TAG, "cells = " + cells);
            android.util.Log.e(TAG, "hasGanado = " + hasGanado);
            android.util.Log.e(TAG, "actual = " + actual);
        } else {
            Utils.muestraMensaje(this, String.format(getResources().getString(R.string.ordenaLaberinto), this.nombreJugador));
        }
        iniPlay(this.laberintoType, false);
    }

    public void iniPlay(String laberintoType, Boolean restart) {
        if (!play(Utils.getResourceId(this, laberintoType, "raw"), restart)) onFinish(null);
        if (restart) this.moves = 0;
        this.tvContador.setText(String.format(getResources().getString(R.string.movimientos), this.moves));
    }

    public void restart() {
        android.util.Log.e(TAG, getResources().getString(R.string.restart));
        this.maze = null;
        this.input = null;
        this.output = null;
        this.actual = null;
        this.hasGanado = false;
    }

    public boolean play(@RawRes int idFile, Boolean restart) {
        if (restart) {
            restart();
            this.mazeViewer.restart();
        }
        this.maze = new Maze(this);
        if (!this.maze.read(idFile)) {
            Log.e(TAG, "Error en play.read");
            return false;
        }
        if (Utils.checkFile(this, idFile) != -1) {
            if (this.input == null) this.input = maze.getInput();
            if (this.output == null) this.output = maze.getOutput();
            if (this.actual == null) this.actual = this.input;
            Log.i(TAG, "input: " + this.input + ", output: " + this.output + ", actual: " + this.actual);
            this.cells = Utils.getZoom();
            this.mazeViewer.setZoom(this.cells);
            printMaze();
            return true;
        } else {
            Utils.muestraMensaje(this, getResources().getString(R.string.noEncontrada));
            return false;
        }
    }

    /***********************************************************************************************/
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_mazeplayer_text, menu);
        Utils.onCreateOptionsMenuItems(this, menu, true);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.musica: {
                item.setIcon(Utils.musicaPlayStop(this, false));
                return true;
            }
            case R.id.x_size: {
                this.cells = mazeViewer.addZoom();
                printMaze();
                return true;
            }
            case R.id.restart: {
                Utils.muestraMensaje(this, getResources().getString(R.string.restart));
                iniPlay(this.laberintoType, true);
                return true;
            }
            case R.id.help: {
                final View v = findViewById(R.id.action_settings);
                Utils.openPopup(this, v, R.id.help);
                return true;
            }
            default: {
                return super.onOptionsItemSelected(item);
            }
        }
    }

    public void openPopup(View view) {
        Utils.openPopup(this, view, view.getId());
    }

    public void openPopup(View view, @IdRes int idPopup) {
        Utils.openPopup(this, view, idPopup);
    }

    /***********************************************************************************************/
    private class DpadClick implements View.OnClickListener {
        public void onClick(View v) {
            if (!hasGanado && actual != null) {
                Point neighbor = Utils.getNeighbor(v, maze, actual);
                if (neighbor != null && !neighbor.isErrorChar() && !neighbor.isBarrier()) {
                    actual = neighbor;
                    moves++;
                }
                printMaze();
                if (actual.equals(output)) {
                    Utils.muestraMensaje(getBaseContext(), String.format(getResources().getString(R.string.ganado), moves));
                    onGanar();
                }
            } else onFinish(v);
        }
    }

    protected void onGanar() {
        this.hasGanado = Utils.onGanar(this, TAG, this.nombreJugador, this.laberintoType, this.moves);
    }

    public void printMaze() {
        this.tvContador.setText(String.format(getResources().getString(R.string.movimientos), this.moves));
        this.mazeViewer.setActual(actual);
        this.mazeViewer.setMaze(this.maze);
        this.mazeViewer.invalidate();
    }

    /****************************************************************/
    public void onFinish(View v) {
        Musica.stop();
        Musica.release();
        finish();
    }
}

