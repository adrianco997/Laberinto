package dm2e.laberinto;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.util.AttributeSet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Originaly created by BunyamiN on 25-5-2015, but heavily modify for our use
 * https://stackoverflow.com/questions/20747138/android-drawing-a-maze-to-canvas-with-smooth-character-movement/
 *
 * @author Adrian Caballero Orasio
 * @author Carlos del Valle Pelaez
 */
public class MazeView extends androidx.appcompat.widget.AppCompatImageView {
    private final String TAG = getClass().getName();
    private Point actual = null;
    private Bitmap[] bitmaps;
    private Maze maze;
    private int iniWidth;
    private int iniHeight;
    private int width;
    private int height;
    private int cells;

    public MazeView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs, (attrs != null) ? attrs.getStyleAttribute() : 0);
        this.cells = Utils.getZoom();
        this.bitmaps = new Bitmap[]{
                FileChars.SPACE.getBitmap(context),
                FileChars.BARRIER.getBitmap(context),
                FileChars.INPUT.getBitmap(context),
                FileChars.OUTPUT.getBitmap(context),
                FileChars.ERRORCHAR.getBitmap(context),
                Movements.UP.getBitmap(context),
                Movements.DOWN.getBitmap(context),
                Movements.LEFT.getBitmap(context),
                Movements.RIGHT.getBitmap(context),
                Movements.VISITED.getBitmap(context),
                Movements.ACTUAL.getBitmap(context),
        };
    }

    @Override
    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int wMode = MeasureSpec.getMode(widthMeasureSpec), hMode = MeasureSpec.getMode(heightMeasureSpec);
        if (wMode == MeasureSpec.EXACTLY) this.width = MeasureSpec.getSize(widthMeasureSpec);
        else if (wMode == MeasureSpec.AT_MOST) this.width = 150;
        if (hMode == MeasureSpec.EXACTLY) this.height = MeasureSpec.getSize(heightMeasureSpec);
        else if (hMode == MeasureSpec.AT_MOST) this.height = 150;
        this.iniWidth = width;
        this.iniHeight = height;
        setMeasuredDimension(width, height);
    }

    public int addZoom() {
        this.cells = Utils.addZoom();
        return this.cells;
    }

    public void setMaze(Maze maze) {
        this.maze = maze;
    }

    public void setZoom(int cells) {
        this.cells = Utils.setZoom(cells);
    }

    public void setActual(Point actual) {
        this.actual = actual;
    }

    public void restart() {
        this.actual = null;
    }

    @Override
    @SuppressLint("DrawAllocation")
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.maze != null && this.actual != null) {
            drawMaze(canvas, this.maze, this.actual,
                    (float) this.width / this.cells / 2,
                    (float) this.height / this.cells / 2);
        }
    }

    public void drawMaze(Canvas canvas, Maze maze, Point actual, float dX, float dY) {
        maze.setDrawValues(bitmaps, cells, width, height);
        maze.drawMaze(canvas, dX, dY, actual);
    }
}
