package dm2e.laberinto;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.annotation.DrawableRes;
import androidx.annotation.StringRes;

/**
 * Constantes publicas que definen los tipos de puntos que se permiten en un laberinto.</br>
 * Simbolos de entrada de fichero
 *
 * @author Adrian Caballero Orasio
 * @author Carlos del Valle Pelaez
 */
public /* static */ enum FileChars {
    // new MazeSolver().getApplicationContext().getResources().getString(R.string.SPACE).toCharArray()[0]
    SPACE(' ', R.string.SPACE, R.drawable.space),
    BARRIER('+', R.string.BARRIER, R.drawable.barrier),
    INPUT('i', R.string.INPUT, R.drawable.input),
    OUTPUT('o', R.string.OUTPUT, R.drawable.output),
    ERRORCHAR('E', R.string.ERRORCHAR, R.drawable.errorchar),
    ;
    public final char c;
    public final @StringRes
    int label;
    public final @DrawableRes
    int image;

    FileChars(char c, @StringRes int label, @DrawableRes int image) {
        this.c = c;
        this.label = label;
        this.image = image;
    }

    public Bitmap getBitmap(Context contexto) {
        return BitmapFactory.decodeResource(contexto.getResources(), this.image);
    }

    public static FileChars valueOf(char c) {
        for (FileChars m : values()) if (m.c == c) return m;
        return null;
    }
}
// typedef enum {RIGHT = 0, UP = 1, LEFT = 2, DOWN = 3, STAY = 4} Move;