package dm2e.laberinto;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.annotation.DrawableRes;
import androidx.annotation.StringRes;

/**
 * Constantes publicas que definen los tipos de puntos que se permiten en un laberinto.</br>
 * Simbolos de entrada de fichero
 *
 * @author Adrian Caballeo Orasio
 */
public /* static */ enum Movements {
    UP('^', R.string.UP, R.drawable. up),
    DOWN('v', R.string.DOWN, R.drawable. donw),
    LEFT('<', R.string.LEFT, R.drawable. left),
    RIGHT('>', R.string.RIGHT, R.drawable. right),
    /**
     * Simbolo para un espacio ya visitado.</br>
     */
    VISITED('x', R.string.VISITED, R.drawable.visited),
    /**
     * Simbolo para un espacio actualmente ocupado.</br>
     */
    ACTUAL('@', R.string.ACTUAL, R.drawable.actual),
    ;
    public final char c;
    @StringRes
    public final int label;
    @DrawableRes
    public final int image;

    Movements(char c, @StringRes int label, @DrawableRes int image) {
        this.c = c;
        this.label = label;
        this.image = image;
    }

    public Bitmap getBitmap(Context contexto) {
        return BitmapFactory.decodeResource(contexto.getResources(), this.image);
    }

    public static Movements valueOf(char c) {
        for (Movements m : values()) if (m.c == c) return m;
        return null;
    }
}
// typedef enum {RIGHT = 0, UP = 1, LEFT = 2, DOWN = 3, STAY = 4} Move;

