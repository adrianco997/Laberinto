package dm2e.laberinto;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.DrawableRes;
import androidx.annotation.RawRes;

import java.util.List;

/**
 * @author Adrian Caballeo Orasio
 */
public class Utils {
    private final String TAG = getClass().getName();
    private static final int cell_min = 5, cell_max = 20, cell_zoom = 5;
    private static int cells = cell_min;
    /**
     * Tamaño maximo de un string en C.
     */
    public static int MAX = 1024; // 4096

    /**********************************************************************************************/
    public static String[] getIntentInfo(Intent intent) {
        String nombreJugador = "jugador", laberintoType = "m3";
        if (intent != null && intent.getStringExtra("nombre") != null) {
            if (!intent.getStringExtra("nombre").equals(""))
                nombreJugador = intent.getStringExtra("nombre");
        }
        if (intent != null && intent.getStringExtra("laberinto") != null) {
            if (!intent.getStringExtra("laberinto").equals(""))
                laberintoType = intent.getStringExtra("laberinto");
        }
        return new String[]{nombreJugador, laberintoType};
    }

    public static int checkFile(Context c, @RawRes int mfile) {
        Movements[] strat = {Movements.LEFT, Movements.UP, Movements.RIGHT, Movements.DOWN,};
        Maze mazeAux = new Maze(c);
        int pathlength;
        if (!mazeAux.read(mfile)) return -1;

        pathlength = mazeAux.deepSearchStack(mazeAux.getInput(), strat);
//		pathlength = mazeAux.breadthSearchQueue(mazeAux.getInput(), strat);
//		pathlength = mazeAux.pathPaint(mazeAux.deepSearchRec(mazeAux.getInput(), strat, false))
        Maze.map_destroy(mazeAux);
        return pathlength;
    }

    public static int getZoom() {
        return cells;
    }

    public static int setZoom(int c) {
        if (c > 0 && c < cell_max) cells = c;
        return cells;
    }

    public static int addZoom() {
        if (cells > 0 && cells < cell_max) cells += cell_zoom;
        else cells = cell_min;
        return cells;
    }

    public static Point getNeighbor(View v, Maze maze, Point actual) {
        Point neighbor = null;
        switch (v.getId()) {
            case R.id.up:
                neighbor = maze.getNeighbor(actual, Movements.UP);
                break;
            case R.id.down:
                neighbor = maze.getNeighbor(actual, Movements.DOWN);
                break;
            case R.id.left:
                neighbor = maze.getNeighbor(actual, Movements.LEFT);
                break;
            case R.id.right:
                neighbor = maze.getNeighbor(actual, Movements.RIGHT);
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + v.getId());
        }
        return neighbor;
    }

    @DrawableRes
    public static int musicaPlayStop(Context c, boolean ini) {
        if (ini) {
            try {
                Musica.creator(c.getApplicationContext(), 1);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }
            if (Musica.isIsMuted()) return R.drawable.ic_music_off;
            else {
                Musica.start();
                return R.drawable.ic_music_on;
            }
        }
        Musica.mute();
        if (Musica.getMp() == null) {
            try {
                Musica.creator(c.getApplicationContext(), 1);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }
        }
        if (Musica.isIsMuted()) return R.drawable.ic_music_off;
        else {
            Musica.start();
            return R.drawable.ic_music_on;
        }
    }

    public static void onCreateOptionsMenuItems(Context c, Menu menu, boolean m) {
        MenuItem /*x, y,*/ musicaItem;
        //SubMenu subMenu = null;//menu.getItem(2).getSubMenu();

        /*try {
            for (int i = 0; menu.getItem(i) != null; i++) {
                if (menu.getItem(i).hasSubMenu()) subMenu = menu.getItem(i).getSubMenu();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (subMenu != null) {
            x = subMenu.getItem(0);//y = subMenu.getItem(1);
        } else {
            x = menu.getItem(R.id.x_size);//y = menu.getItem(R.id.y_size);
        }/**/

        musicaItem = menu.findItem(R.id.musica);// menu.getItem(0);
        musicaItem.setIcon(Utils.musicaPlayStop(c.getApplicationContext(), m));

        //x.setTitle(c.getApplicationContext().getString(R.string.x_size, cells));
        //y.setTitle(c.getApplicationContext().getString(R.string.y_size, cells));
    }


    protected static boolean onGanar(Context c,String TAG, String nombreJugador, String laberintoType, int moves) {
        long id = 0;
        boolean hasGanado = true;
        //onPause();
        try {
            SQLiteHelper_Ranking db = SQLiteHelper_Ranking.getInstance(c.getApplicationContext());
            Ranking ranking = new Ranking(nombreJugador, laberintoType, moves);
            id = db.addOrUpdateRanking(ranking);/*db.addRanking(ranking);*/
//            actualizarBD();
        } catch (Exception e) {
            Log.e(TAG, "(" + id + ": " + e);
        }
//        actualizarBD();
        return hasGanado;
    }

    protected static void actualizarBD(Context c, TextView tv) {
        try {
            SQLiteHelper_Ranking db = SQLiteHelper_Ranking.getInstance(c.getApplicationContext());
            List<Ranking> ranking = db.getAllRankings();
            String txt = "";
            for (Ranking r : ranking) {
                txt = String.format("%s%s<br>", txt, r.toString(c.getApplicationContext()));
            }
            tv.setText(getSpannedText(c.getApplicationContext().getString(R.string.rankings, txt)));
        } catch (Exception e) {
            Utils.muestraMensaje(c.getApplicationContext(), R.string.errorGanardores);
            e.printStackTrace();
        }
    }

    public void openPopup(Context c, View view) {
        openPopup(c, view, view.getId());
    }

    public static void openPopup(Context c, View view, /*@IdRes*/ int idPopup) {
        if (view == null) Utils.muestraMensaje(c.getApplicationContext(), "Error al abrir poup");

        int width = LinearLayout.LayoutParams.WRAP_CONTENT, height = LinearLayout.LayoutParams.WRAP_CONTENT;
        LayoutInflater lInflater = (LayoutInflater) c.getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        LayoutInflater inflater = (LayoutInflater) c.getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        PopupWindow pw = new PopupWindow(inflater.inflate(R.layout.popup_window, null, false), 100, 100, true);

        View popupView = lInflater.inflate(R.layout.popup_window, null);
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, true);

        popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
        TextView tv = popupView.findViewById(R.id.tv_popup);
        View accept = popupView.findViewById(R.id.accept_popup);
        View cancel = popupView.findViewById(R.id.cancel_popup);

        switch (idPopup) {
            case R.id.menu_settings: {
                break;
            }
            //case R.id.popup_ranking:
            case R.id.menu_ranking: {
                Utils.actualizarBD(c.getApplicationContext(), tv);
                tv.setGravity(Gravity.NO_GRAVITY);
                accept.setVisibility(View.GONE);
                cancel.setVisibility(View.VISIBLE);
                break;
            }
            case R.id.help: {
                tv.setText(Utils.getSpannedText(c.getApplicationContext().getString(R.string.popup_help)));
                tv.setGravity(Gravity.NO_GRAVITY);
                accept.setVisibility(View.GONE);
                cancel.setVisibility(View.VISIBLE);
                break;
            }
            //case R.id.popup_info:
            case R.id.menu_info: {
                tv.setText(Utils.getSpannedText(c.getApplicationContext().getString(R.string.popup_informacion)));
                tv.setGravity(Gravity.CENTER);
//                tv.setText(R.string.informacion);
                accept.setVisibility(View.GONE);
                cancel.setVisibility(View.VISIBLE);
                break;
            }

        }
//        if(accept.getVisibility() == View.VISIBLE) {accept.setOnClickListener(new View.OnClickListener() {@Override public void onClick(View v) { }});}
        if (cancel.getVisibility() == View.VISIBLE) {
            cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    popupWindow.dismiss();
                }
            });
        } else {
            popupView.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    popupWindow.dismiss();
                    return true;
                }
            });
        }
    }

    public static Spanned getSpannedText(String text) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return Html.fromHtml(text);
        else return Html.fromHtml(text, Html.FROM_HTML_MODE_COMPACT);
    }//public static CharSequence getText(Context context, int id, Object... args) { for (int i = 0; i < args.length; ++i) args[i] = (args[i] instanceof String) ? TextUtils.htmlEncode((String) args[i]) : args[i];return Html.fromHtml(String.format(Html.toHtml(new SpannedString(context.getText(id))), args)); }

    public static int getResourceId(Context c, String name, String defType) {
        return c.getApplicationContext().getResources().getIdentifier(name, defType, c.getApplicationContext().getPackageName());
    }

    protected static void muestraMensaje(Context c, String txt) {
        Toast t = Toast.makeText(c, txt, Toast.LENGTH_LONG);
        t.setGravity(Gravity.CENTER, 0, 0);
        t.show();
    }

    protected static void muestraMensaje(Context c, int id) {
        Toast t = Toast.makeText(c, id, Toast.LENGTH_LONG);
        t.setGravity(Gravity.CENTER, 0, 0);
        t.show();
    }

    /**********************************************************************************************/
    //4,12,8
    public static String formatC(String txt, char c, int n) {
        if (txt.length() % 2 == 0 && n % 2 == 0)
            return String.format(String.format("%" + ((n - txt.length()) / 2 + 0) + "s%s%" + -((n - txt.length()) / 2 + 0) + "s", "", "%s", "").replace(' ', c), txt)/*+1*/;
        if (txt.length() % 2 == 0 && n % 2 == 1)
            return String.format(String.format("%" + ((n - txt.length()) / 2 + 0) + "s%s%" + -((n - txt.length()) / 2 + 1) + "s", "", "%s", "").replace(' ', c), txt)/*+2*/;
        if (txt.length() % 2 == 1 && n % 2 == 0)
            return String.format(String.format("%" + ((n - txt.length()) / 2 + 1) + "s%s%" + -((n - txt.length()) / 2 + 0) + "s", "", "%s", "").replace(' ', c), txt)/*+3*/;
        if (txt.length() % 2 == 1 && n % 2 == 1)
            return String.format(String.format("%" + ((n - txt.length()) / 2 + 0) + "s%s%" + -((n - txt.length()) / 2 + 0) + "s", "", "%s", "").replace(' ', c), txt)/*+4*/;
//		return String.format(String.format("%" + ((n - txt.length()) / 2) + "s%s%" + -((n - txt.length()) / 2 + ((n - txt.length() %2==0)?0:1)) + "s", "", "%s", "").replace(' ', c), txt);
        return "zz";
    }

    public static String formatL(String txt, char c, int n) {
        return String.format(String.format("%" + +(n - txt.length() + 2) + "s", "%s").replace(' ', c), txt);
    }

    public static String formatR(String txt, char c, int n) {
        return String.format(String.format("%" + -(n - txt.length() + 2) + "s", "%s").replace(' ', c), txt);
    }
}


