package com.example.splash;

import android.app.Application;
import android.os.SystemClock;

public class Splash extends Application
{
    @Override
    public void onCreate() {
        super.onCreate();
        SystemClock.sleep(5000);
    }
}