/*
 * File: tree.c
 * Authors: Adrian Caballero Orasio, Frederik Mayer
 * Created on 25 de marzo de 2018, 09:00
 */

#include "tree.h"

typedef struct _NodeBT {
    void *info;
    struct _NodeBT *left;
    struct _NodeBT *right;
} NodeBT;

struct _Tree {
    NodeBT *root;
    destroy_element_function_type destroy_element_function;
    copy_element_function_type    copy_element_function;
    print_element_function_type   print_element_function;
    cmp_element_function_type     cmp_element_function;
};

/**************************************************/
void nodebt_destroy(NodeBT *pn, destroy_element_function_type destroy_element);

Status nodebt_insert(NodeBT *pn, const void *po, destroy_element_function_type destroy_element, copy_element_function_type copy_element, cmp_element_function_type cmp_element);
Bool nodebt_find(NodeBT *pn, const void *po, cmp_element_function_type cmp_element);

int nodebt_depth(NodeBT *pn);
int nodebt_numNodes(NodeBT *pn);

Status nodebt_preOrder (FILE *f, const NodeBT *pn, print_element_function_type print_element);
Status nodebt_inOrder  (FILE *f, const NodeBT *pn, print_element_function_type print_element);
Status nodebt_postOrder(FILE *f, const NodeBT *pn, print_element_function_type print_element);
/**************************************************/
Tree *tree_ini(destroy_element_function_type f1, copy_element_function_type f2, print_element_function_type f3, cmp_element_function_type f4) {
    Tree *pa = NULL;

    pa = (Tree *) malloc(sizeof(Tree));
    if(!pa) return NULL;
    pa->root = NULL;
    pa->destroy_element_function = f1;
    pa->copy_element_function = f2;
    pa->print_element_function = f3;
    pa->cmp_element_function = f4;
    return pa;
}
void tree_destroy(Tree *pa) {
    if (!pa) return;
    nodebt_destroy(pa->root, pa->destroy_element_function);
    free(pa);
}

Status tree_insert(Tree *pa, const void *po) {
    if (!pa || !po) return ERROR;
    return nodebt_insert(pa->root, po, pa->destroy_element_function, pa->copy_element_function, pa->cmp_element_function);
}
Bool tree_find(Tree *pa, const void *po) {
    if (!pa || !po) return FALSE;
    return nodebt_find(pa->root, po, pa->cmp_element_function);
}

Bool tree_isEmpty(const Tree *pa) {
    if (!pa || !pa->root) return TRUE;
    return FALSE;
}
int tree_depth(const Tree *pa) {
    if (tree_isEmpty(pa) == FALSE) return nodebt_depth(pa->root);
    else return -1;
}
int tree_numNodes(const Tree *pa) {
    if (tree_isEmpty(pa) == FALSE) return nodebt_numNodes(pa->root);
    else return 0;
}

/******** Funciones de recorrido del árbol ********/
Status tree_preOrder(FILE *f, const Tree *pa) {
    if (!f || !pa || !pa->root) return ERROR;
    return nodebt_preOrder(f, pa->root, pa->print_element_function);
}
Status tree_inOrder(FILE *f, const Tree *pa) {
    if (!f || !pa || !pa->root) return ERROR;
    return nodebt_inOrder(f, pa->root, pa->print_element_function);
}
Status tree_postOrder(FILE *f, const Tree *pa) {
    if (!f || !pa || !pa->root) return ERROR;
    return nodebt_postOrder(f, pa->root, pa->print_element_function);
}

/**************************************************/
void nodebt_destroy(NodeBT *pn, destroy_element_function_type destroy_element) {
    if (pn) {
        if (pn->left) nodebt_destroy(pn->left, destroy_element);
        if (pn->right) nodebt_destroy(pn->right, destroy_element);
        destroy_element(pn->info);
        free(pn);
    }
}

Status nodebt_insert(NodeBT *pn, const void *po, destroy_element_function_type destroy_element, copy_element_function_type copy_element, cmp_element_function_type cmp_element) {
    int cmp;

    if (!pn) {
        pn = (NodeBT *) malloc(sizeof(NodeBT));
        if (pn) {
            pn->left = NULL;
            pn->right = NULL;
            pn->info = copy_element(po);
            if (pn->info) return OK;
        }
        destroy_element(pn->info);
        free(pn);
        return ERROR;
    }
    cmp = cmp_element(po, pn->info);
    if (cmp < 0) return nodebt_insert(pn->left, po, destroy_element, copy_element, cmp_element);
    if (cmp > 0) return nodebt_insert(pn->right, po, destroy_element, copy_element, cmp_element);
    return OK;
}
Bool nodebt_find(NodeBT *pn, const void *po, cmp_element_function_type cmp_element) {
    int cmp;

    if (!pn) return FALSE;
    cmp = cmp_element(po, pn->info);
    if (cmp < 0) return nodebt_find(pn->left, po, cmp_element);
    if (cmp > 0) return nodebt_find(pn->right, po, cmp_element);
    return TRUE;
}

int nodebt_depth(NodeBT *pn) {
    int left = -1, right = -1;

    if (pn && pn->info) {
        left = nodebt_depth(pn->left);
        right = nodebt_depth(pn->right);
        if (left>right) return (left + 1);
        else return (right + 1);
    }
    return -1;
}
int nodebt_numNodes(NodeBT *pn) {
    if (pn && pn->info) return (nodebt_numNodes(pn->left) + nodebt_numNodes(pn->right) + 1);
    return 0;
}

Status nodebt_preOrder(FILE *f, const NodeBT *pn, print_element_function_type print_element) {
    if (!pn || !pn->info) return ERROR;
    print_element(f, pn->info);
    if (pn->left && pn->left->info) nodebt_preOrder(f, pn->left, print_element);
    if (pn->right && pn->right->info) nodebt_preOrder(f, pn->right, print_element);
    return OK;
}
Status nodebt_inOrder(FILE *f, const NodeBT *pn, print_element_function_type print_element) {
    if (!pn || !pn->info) return ERROR;
    if (pn->left && pn->left->info) nodebt_inOrder(f, pn->left, print_element);
    print_element(f, pn->info);
    if (pn->right && pn->right->info) nodebt_inOrder(f, pn->right, print_element);
    return OK;
}
Status nodebt_postOrder(FILE *f, const NodeBT *pn, print_element_function_type print_element) {
    if (!pn || !pn->info) return ERROR;
    if (pn->left && pn->left->info) nodebt_postOrder(f, pn->left, print_element);
    if (pn->right && pn->right->info) nodebt_postOrder(f, pn->right, print_element);
    print_element(f, pn->info);
    return OK;
}
