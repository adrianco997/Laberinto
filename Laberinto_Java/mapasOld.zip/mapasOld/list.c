/*
 * File: list.c
 * Authors: Adrian Caballero Orasio, Frederik Mayer
 * Created on 21 de marzo de 2018, 09:28
 */

#include "list.h"

typedef struct _Node {
    void *data;
    struct _Node *next;
} Node;

struct _List {
    Node *node;
    destroy_elementlist_function_type destroy_element_function;
    copy_elementlist_function_type    copy_element_function;
    print_elementlist_function_type   print_element_function;
    cmp_elementlist_function_type     cmp_element_function;
};

/*private functions to handle Nodes*/
/*Inicializa un nodo*/
Node* node_ini();
/*Copia el data y lo asigna al nodo*/
Status node_set_data(Node* node, const void* data, copy_elementlist_function_type copy_element_function);
/*Devuelve el puntero del element guardado en el nodo.*/
void* node_get_data(Node* node);
/*Libera un nodo*/
void node_destroy(Node* node, destroy_elementlist_function_type destroy_element_function);
/*function needed by the merge sort algorithm
(not needed for the task, because sorting should be done directly when inserting,
but was already done and working when we noticed...)*/
Status merge(List* whole_list, List* left_list, List* right_list);


List *list_ini(destroy_elementlist_function_type f1, copy_elementlist_function_type f2,
                print_elementlist_function_type f3, cmp_elementlist_function_type f4) {
    List *list = NULL;
    Node *head=NULL;

    list = (List *) malloc(sizeof(List));
    head = node_ini();

    if (!list) return NULL;
    list->node = head;
    list->destroy_element_function = f1;
    list->copy_element_function = f2;
    list->print_element_function = f3;
    list->cmp_element_function = f4;
    return list;
}
void list_free(List *list) {
    if (list) {
        Node* first=list->node;
        Node* next=NULL;
        while (first) {
            next=first->next;
            node_destroy(first, list->destroy_element_function);
            first=next;
        }
        free(list);
        list = NULL;
    }
}

Status list_insertFirst(List *list, const void *elem) {
    Node *temp = NULL;

    if (!list || !elem) return ERROR;
    temp = node_ini();
    if (!temp) return ERROR;
    temp->data = (list->copy_element_function)(elem);
    if (!(temp->data)) {
        node_destroy(temp, list->destroy_element_function);
        return ERROR;
    }
    if (list_isEmpty(list)==FALSE){
      temp->next = list->node;
      list->node = temp;
    }
    else{
      node_destroy(list->node, list->destroy_element_function);
      list->node = temp;
    }
    return OK;
}
Status list_insertLast(List *list, const void *elem) {
    Node *temp = NULL, *aux = NULL;

    if (!list || !elem) return ERROR;
    temp = node_ini();
    if (!temp) return ERROR;
    temp->data = (list->copy_element_function)(elem);
    if (!temp->data) {
        node_destroy(temp, list->destroy_element_function);
        return ERROR;
    }
    if (list_isEmpty(list) == TRUE) {
        node_destroy(list->node, list->destroy_element_function);
        list->node = temp;
        return OK;
    }
    else{
      aux = list->node;
      while (aux->next!=NULL) {
        aux = aux->next;
      }
      aux->next = temp;
    }
    return OK;
}
Status list_insertInOrder(List *list, const void *pElem) {
    Node *temp = NULL, *aux = NULL;

    if (!list || !pElem) return ERROR;

    aux = node_ini();
    if (!aux) return ERROR;
    if (node_set_data(aux, pElem, list->copy_element_function)==ERROR) {
        node_destroy(aux, list->destroy_element_function);
        return ERROR;
    }
    if (list_isEmpty(list) == TRUE) {
      node_destroy(list->node, list->destroy_element_function);
      list->node = aux;
    }
    else if(list_size(list)==1){
      if((list->cmp_element_function)(node_get_data(list->node),pElem)<0){
        list->node->next = aux;
      }
      else{
        aux->next=list->node;
        list->node=aux;
      }
    }
    else{
      temp = list->node;
      if((list->cmp_element_function)(node_get_data(list->node),pElem)>0){
        aux->next=list->node;
        list->node=aux;
      }
      else{
        while (temp->next!=NULL && (list->cmp_element_function)(node_get_data(temp->next), pElem) < 0) {
          temp = temp->next;
        }
        /*after this while loop, temp contains either the last element of the list,
          or the last element that's smaller than pElem.
          In both cases, the new element has to be inserted after temp.*/
        if(temp->next==NULL){
          temp->next=aux;
        }
        else{
          aux->next=temp->next;
          temp->next=aux;
        }
      }
    }
    return OK;
}

void *list_extractFirst(List *list) {
    void *pElem = NULL;
    Node* new_first_node=NULL;

    if (!list || list_isEmpty(list) == TRUE) return NULL;
    pElem=(list->copy_element_function)(node_get_data(list->node));
    if (!(new_first_node=list->node->next)){
      (list->destroy_element_function)(node_get_data(list->node));
      list->node->data=NULL;
      list->node->next=NULL;
    }
    else{
      node_destroy(list->node, list->destroy_element_function);
      list->node=new_first_node;
    }
    return pElem;
}
void *list_extractLast(List *list) {
    Node *ultimate = NULL, *penultimate = NULL;
    void *elem = NULL;

    if (!list || list_isEmpty(list) == TRUE) return NULL;
    if(list_size(list)==1){
      elem=(list->copy_element_function)(node_get_data(list->node));
      (list->destroy_element_function)(node_get_data(list->node));
      list->node->data=NULL;
      return elem;
    }
    penultimate = list->node;
    ultimate = list->node->next;
    while (ultimate->next != NULL) {
        penultimate = ultimate;
        ultimate = ultimate->next;
    }
    if (!(elem = (list->copy_element_function)(node_get_data(ultimate)))){
      return NULL;
    }
    node_destroy(ultimate, list->destroy_element_function);
    penultimate->next = NULL;
    return elem;
}

Bool list_isEmpty(const List *list) {
    if (!list) return FALSE;
    if (!(node_get_data(list->node))) return TRUE;
    return FALSE;
}

const void *list_get(const List *list, int i) {
    Node *temp = NULL;
    int n = 1;

    temp = list->node;
    while (temp->next && n < i) {
        temp = temp->next;
        n++;
    }
    if (n == i) return temp->data;
    else return NULL;
}

int list_size(const List *list) {
    Node *temp = NULL;
    int cuenta = 1;

    if (list_isEmpty(list)){
      return 0;
    }
    temp = list->node;
    while (temp->next) {
        temp = temp->next;
        cuenta++;
    }
    return cuenta;
}
int list_print(FILE *fd, const List *list) {
    Node *temp = NULL;
    int cuenta = 0;

    if(list_isEmpty(list)==TRUE){
      fprintf(fd, "List is empty.\n");
    }

    temp = list->node;
    while (temp) {
        (list->print_element_function)(fd, temp->data);
        temp = temp->next;
        cuenta++;
    }
    return cuenta;
}




Node* node_ini(){
  Node* new_node=(Node *) malloc(sizeof(Node));
  new_node->data=NULL;
  new_node->next=NULL;
  return new_node;
}

Status node_set_data(Node* node, const void* data, copy_elementlist_function_type copy_element_function){
  node->data=copy_element_function(data);
  if(!node->data){
    return ERROR;
  }
  return OK;
}

void* node_get_data(Node* node){
  if(!node){
    return NULL;
  }
  return node->data;
}


void node_destroy(Node* node, destroy_elementlist_function_type destroy_element_function){
  destroy_element_function(node->data);
  free(node);
}





/*merges two lists, that are both sorted themselves*/
Status merge(List* whole_list, List* left_list, List* right_list){
  printf("Merge list:\n");
  list_print(stdout,left_list);
  printf("with list:\n");
  list_print(stdout,right_list);

  if (list_isEmpty(whole_list)==FALSE){
    return ERROR;
  }
  while (list_isEmpty(left_list)==FALSE && list_isEmpty(right_list)==FALSE){
    printf("Inserting from both lists\n");
    printf("Compare: %d\n", (whole_list->cmp_element_function)(list_get(left_list,1),list_get(right_list,1)));
    if((whole_list->cmp_element_function)(list_get(left_list,1),list_get(right_list,1))>=0){
      if (list_insertLast(whole_list,list_extractFirst(left_list))==ERROR){
        return ERROR;
      }
    }
    else{
      if (list_insertLast(whole_list,list_extractFirst(right_list))==ERROR){
        return ERROR;
      }
    }
  }
  while (list_isEmpty(left_list)==FALSE){
    if (list_insertLast(whole_list,list_extractFirst(left_list))==ERROR){
      return ERROR;
    }
  }
  while (list_isEmpty(right_list)==FALSE){
    if (list_insertLast(whole_list,list_extractFirst(right_list))==ERROR){
      return ERROR;
    }
  }
  return OK;
}

Status list_merge_sort(List* list){
  int i=0;
  int listsize=list_size(list);
  if(!list){
    return ERROR;
  }
  if (list_size(list)==1){
    return OK;
  }
  else{
    List* left_list=list_ini(list->destroy_element_function, list->copy_element_function,
      list->print_element_function, list->cmp_element_function);
    List* right_list=list_ini(list->destroy_element_function, list->copy_element_function,
      list->print_element_function, list->cmp_element_function);

    printf("------------------------------------List of size: %d\n", list_size(list));
    list_print(stdout, list);
    for(i=0; i<(int)listsize/2; i++){
      printf("i=%d\n", i);
      list_insertFirst(left_list, list_extractFirst(list));
      printf("Left list:\n");
      list_print(stdout, left_list);
      printf("Right list:\n");
      list_print(stdout, right_list);
    }
    printf("-------------------------------------Left list done.\n");
    for(i=(int)listsize/2; i<listsize; i++){
      printf("i=%d\n", i);
      list_insertFirst(right_list, list_extractFirst(list));
      printf("Left list:\n");
      list_print(stdout, left_list);
      printf("Right list:\n");
      list_print(stdout, right_list);
    }
    printf("Remaining list:\n");
    list_print(stdout, list);
    if (list_isEmpty(list)==FALSE){
      return ERROR;
    }
    printf("Call merge sort with left list:\n");
    if (list_merge_sort(left_list)==ERROR){
      return ERROR;
    }
    if (list_merge_sort(right_list)==ERROR){
      return ERROR;
    }

    if (merge(list, left_list, right_list)==ERROR){
      return ERROR;
    }
    list_free(left_list);
    list_free(right_list);
    return OK;
  }
}
