/*
 * File: stack_fp.c
 * Authors: Adrian Caballero Orasio, Frederik Mayer
 * Created on 21 de febrero de 2018, 09:00
 */

#include "stack_fp.h" 

struct _Stack {
    int top;
    void *item[MAXSTACK];
    destroy_element_function_type   destroy_element_function;
    copy_element_function_type      copy_element_function;
    print_element_function_type     print_element_function;
};

Stack *stack_ini(destroy_element_function_type f1, copy_element_function_type f2, print_element_function_type f3) {
    Stack *stack = NULL;
    int i;

    stack = (Stack *) malloc(sizeof(Stack));
    if(!stack) return NULL;
    for (i=0; i<MAXSTACK; i++) {
        stack->item[i] = NULL; /* stack->item[i] = element_ini(); */
    }
    stack->top = -1;
    stack->destroy_element_function = f1;
    stack->copy_element_function = f2;
    stack->print_element_function = f3;
    return stack;
}

void stack_destroy(Stack *stack) {
    int i;

    if (stack) {
        for (i=0; i<MAXSTACK; i++) {
            stack->destroy_element_function(stack->item[i]);
            stack->item[i] = NULL;
        }
        free(stack);
        stack = NULL;
    }
}

Status stack_push(Stack *stack, const void *el) { /* Insertar */
    void *auxel = NULL;

    if (!stack || !el || (stack_isFull(stack) == TRUE)) return ERROR;
    auxel = stack->copy_element_function(el);
    if (!auxel) return ERROR;
    stack->top++;
    stack->destroy_element_function(stack->item[stack->top]);
    stack->item[stack->top] = auxel;
    return OK;
}
void *stack_pop(Stack *stack) { /* Extraer */
    void *el = NULL;

    if (!stack || (stack_isEmpty(stack) == TRUE)) return NULL;
    el = stack->copy_element_function(stack->item[stack->top]);
    stack->destroy_element_function(stack->item[stack->top]);
    stack->item[stack->top] = NULL;
    stack->top--;
    return el;
}
void *stack_top(const Stack *stack) {
    void *auxel = NULL;

    if (!stack || (stack_isEmpty(stack) == TRUE)) return NULL;
    auxel = stack->copy_element_function(stack->item[stack->top]);
    if (!auxel) return NULL;
    return auxel;
}

Bool stack_isEmpty(const Stack *stack) {
    if (!stack || (stack->top == -1)) return TRUE;
    return FALSE;
}
Bool stack_isFull(const Stack *stack) {
    if (!stack || (stack->top == MAXSTACK-1)) return TRUE;
    return FALSE;
}

 int stack_print(FILE *file, Stack *stack) {
    int cuenta = 0;
    void *auxel = NULL;
    Stack *aux = NULL;

    if (!file || !stack) return -1;
    aux=stack_ini(stack->destroy_element_function, stack->copy_element_function, stack->print_element_function);
    if (!aux) return -1;

    /* extrae a copia y cuenta */
        while (stack_isEmpty(stack)==FALSE) {
        auxel = stack_pop(stack);
        if (!auxel) return -1;
        (stack->print_element_function)(file, auxel);
        stack_push(aux, auxel);
        (aux->destroy_element_function)(auxel);
        auxel = NULL;
        cuenta++;
        }
        while (stack_isEmpty(aux)==FALSE) {
        auxel = stack_pop(aux);
        if (!auxel) return -1;
        stack_push(stack, auxel);
        (aux->destroy_element_function)(auxel);
        auxel = NULL;
    }
    stack_destroy(aux);
    aux = NULL;
    return cuenta;
}
