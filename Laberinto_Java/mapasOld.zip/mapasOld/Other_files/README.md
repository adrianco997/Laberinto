*PARTE 1. EJERCICIOS*

#Ejercicio 1 (P3_E1). Cola (genérica) de puntos

1.Definición del TAD Cola (Queue) circular. Implementación: selección de estructura de datos e implementación de primitivas.

Se pide implementar en el fichero queue.c las primitivas del TAD Cola que se definen en el archivo de cabecera queue.h (ver Apéndice 1) utilizando punteros a función, como se hizo en el último ejercicio de la P2. Los tipos Status y Bool son los definidos en types.h. La constante MAXQUEUE indica el tamaño máximo de la cola. Su valor debe permitir desarrollar los ejercicios propuestos.

La estructura de datos elegida para implementar el TAD COLA consiste en un array de punteros genéricos (void*) y referencias a los elementos situados en la cabeza y al final de la cola, así como punteros a las funciones de destrucción, copia e impresión de los elementos. Dicha estructura se muestra a continuación:
**.
    /* En queue.h */
    typedef struct _Queue Queue;
    /* En queue.c */
    struct _Queue {
        void **head;
        void **end;
        void* item[MAXQUEUE];
        destroy_elementqueue_function_type   destroy_element_function;
        copy_elementqueue_function_type      copy_element_function;
        print_elementqueue_function_type     print_element_function;
    };
.**
2. Comprobación de la corrección de la definición del tipo Queue y sus funciones. Con el objetivo de evaluar el funcionamiento de las funciones anteriores, se desarrollará un programa p3_e1.c que trabajará con colas de puntos. Este programa recibirá como argumento un fichero, cuya primera línea indicará el número de puntos que se deben leer (siguiendo el formato que podéis ver en la salida esperada), y los introducirá uno a uno en una cola. A continuación, irá sacando de dicha cola la mitad de los puntos introducidos y los introducirá en una cola, introduciendo la otra mitad en una cola distinta. Durante el proceso,el contenido de las tres colas se irá imprimiendo como se muestra a continuación en la salida esperada:
**.
    > cat puntos.txt
    3
    1,1,+
    2,2,v
    3,3,
    > ./p3_e1 puntos.txt
    Cola 1: Queue vacia.
    Cola 2: Queue vacia.
    Cola 3: Queue vacia.
    Cola 1: Cola con 1 elementos:
    [(1, 1): +]
    Cola 2: Queue vacia.
    Cola 3: Queue vacia.
    Cola 1: Cola con 2 elementos:
    [(1, 1): +]
    [(2, 2): v]
    Cola 2: Queue vacia.
    Cola 3: Queue vacia.
    Cola 1: Cola con 3 elementos:
    [(1, 1): +]
    [(2, 2): v]
    [(3, 3):  ]
    Cola 2: Queue vacia.
    Cola 3: Queue vacia.
    <<<Pasando la primera mitad de Cola 1 a Cola 2
    Cola 1: Cola con 2 elementos:
    [(2, 2): v]
    [(3, 3):  ]
    Cola 2: Cola con 1 elementos:
    [(1, 1): +]
    Cola 3: Queue vacia.
    <<<Pasando la segunda mitad de Cola 1 a Cola 3
    C
    ola 1: Cola con 1 elementos:
    [(3, 3):  ]
    Cola 2: Cola con 1 elementos:
    [(1, 1): +]
    Cola 3: Cola con 1 elementos:
    [(2, 2): v]
    Cola 1: Queue vacia.
    Cola 2: Cola con 1 elementos:
    [(1, 1): +]
    Cola 3: Cola con 2 elementos:
    [(2, 2): v]
    [(3, 3):  ]
    Cola 1:
    Queue vacia.
    Cola 2: Cola con 1 elementos:
    [(1, 1): +]
    Cola 3: Cola con 2 elementos:
    [(2, 2): v]
    [(3, 3):  ]
.**


#Ejercicio 2 (P3_E2). Resolución de un mapa usando una cola.
En la práctica anterior (P2_E3) se ha realizado esta funcionalidad apoyándose en una pila. Se trata de sustituir en ese algoritmo la pila por una cola. De esta forma se cambiará el orden en el que se exploran los movimientos pendientes. En este ejercicio, por tanto, se trata de que se comprueben esas diferencias.
El programa implementado se escribirá en un fichero de nombre p3_e2.c y los argumentos de entrada, así como el formato de salida, serán los mismos que los del ejercicio P2_E3.
Además, este programa debe ser capaz de devolver el camino (óptimo) encontrado.
Para ello, se puede hacer uso de la siguiente estructura de datos para Point, de manera que permita almacenar el punto anterior (o padre) para luego mostrar el camino completo:
**.
    struct _Point{
        int x, y;
        char symbol;
        struct _Point *parent;
    };
.**
Se sugiere utilizar una función recursiva que imprima el camino encontrado desde el principio hasta el final como se muestra a continuación en la salida esperada:
**.
    > ./p3_e2 m1.txt
    Existe un camino:
    [(1, 1): i]
    [(2, 1): V]
    [(3, 1): V]
    [(4, 1): V]
    [(4, 2): V]
    [(4, 3): V]
    [(3, 3): V]
    [(2, 3): V]
    [(1, 3): V]
    [(1, 4): V]
    [(1, 5): o]
.**
También se podría imprimir el camino en el propio mapa complementando la salida anterior (donde se ha utilizado un carácter especial para el camino más corto, diferente al carácter V):
**.
    7 6
    ++++++
    +i...+
    ++++.+
    +....+
    +.   +
    +o++ +
    ++++++
.**

#Ejercicio 3(P3_E3).
Resolución de mapas según diferentes estrategias En este mismo contexto, se pretende generalizar el estudio de los mapas mediante la comprobación de la eficiencia de diferentes estrategias.
Entenderemos por estrategia simplemente un orden entre los movimientos posibles del mapa.
Nos limitaremos a estrategias que utilicen exactamente 4 movimientos y sólo uno cada vez. Por lo tanto, una estrategia no es más que una permutación en el conjunto de 4 movimientos.
Para su implementación en C se utilizará un vector que podrá contener 4 elementos de tipo Move según, por ejemplo,esta declaración:
**.
    Move strategy[] = { RIGHT, LEFT, UP, DOWN };
.**
Cuando se desee probar más de una estrategia se seguirá este esquema, utilizando una matriz 2D como en el siguiente ejemplo:
**.
    Move strategies[4][4] = {
                                { RIGHT, LEFT, UP, DOWN },
                                { DOWN, RIGHT, LEFT, UP },
                                { UP, DOWN, RIGHT, LEFT },
                                { LEFT, UP, DOWN, RIGHT }
                            };
.**
Para completar esta parte hay que seguir los siguientes pasos:
    • Crear un módulo propio para las funciones relacionadas con la resolución del mapa. Este módulo se llamará map_solver (.c y .h).
    • Implementar en dicho módulo las funciones
    **.
        int mapsolver_stack(const char* map_file, const Move strat[4]);
    .**
    y
    **.
        int mapsolver_queue(const char *map_file, const Move strat[4]);
    .**
    Las cuales devuelven un número positivo si el mapa tiene solución o uno negativo si no, utilizando en el primer caso una pila para resolver el laberinto (como en P2_E3) o una cola en el segundo (como en P3_E2).Este número indicará la longitud del camino óptimo según la estrategia y el TAD (pila o cola), o, si no se sabe obtener dicha longitud, el número de movimientos que se realiza para resolver cada mapa, el cual será mayor o igual a la longitud del camino óptimo.
    Nótese que estas funciones ahora reciben un vector de movimientos, de manera que al explorar los vecinos se tendrá que usar el orden indicado en este vector, y no como se hubiera hecho en los ejercicios previos.
    • Por último, implementar una función que llame a las anteriores con una matriz de movimientos:
    **.
        void mapsolver_run(const char* map_file, const Move strat[][4], const intnum_strategies);
    .**
    Esta función probará todas las estrategias que se pasen como argumento usando tanto una pila como una cola, llamando a las funciones descritas previamente.
    Para entender la declaración de esta función es necesario recordar las peculiaridades del uso de matrices 2D en el lenguaje de programación.
    Tanto la evolución del proceso como la solución final se mostrarán por la salida estándar (stdout):
        o Cuando se comienza la prueba de una estrategia con el siguiente mensaje:
            “ESTRATEGIA 0213” (correspondiente al array {RIGHT,LEFT,UP,DOWN}).
        o Al finalizar, se indica si ha habido solución (“SALIDA ENCONTRADA” o “SALIDA NO ENCONTRADA”) así como el número de movimientos realizados.


#Ejercicio 4(P3_E4). Lista de enteros incluyendo inserción en orden
1. Definición del TAD Lista (List). Implementación: selección de estructura de datos e implementación de primitivas.
Se pide implementar en el fichero list.c las primitivas del TAD Lista que se definen en el archivo de cabecera list.h. En esta ocasión, la estructura de datos elegida para implementar el TAD Lista consistirá en una estructura con un campo capaz de almacenar el dato y un apuntador al siguiente elemento de la lista. Dicha estructura se muestra a continuación:
**.
    /* En list.h */
    typedef struct _List List;
    /* En list.c */
    typedef struct _Node{
        void *data;
        struct _Node *next;
    } Node;
    struct _List {
        Node *node;
        destroy_elementlist_function_type   destroy_element_function;
        copy_elementlist_function_type      copy_element_function;
        print_elementlist_function_type     print_element_function;
        cmp_elementlist_function_type       cmp_element_function;
    };
    las primitivas de este apartado están indicadas en el apéndice 2.
.**



**..** **..** **..** **..**
