/*
 * File: queue.c
 * Authors: Adrian Caballero Orasio, Frederik Mayer
 * Created on 21 de marzo de 2018, 09:28
 */

#include "queue.h"

#define MAXQUEUE 4096

struct _Queue {
    void **head;
    void **end;
    void *item[MAXQUEUE];
    destroy_elementqueue_function_type   destroy_element_function;
    copy_elementqueue_function_type      copy_element_function;
    print_elementqueue_function_type     print_element_function;
};

Queue *queue_ini(destroy_elementqueue_function_type f1, copy_elementqueue_function_type f2, print_elementqueue_function_type f3) {
    Queue *q = NULL;
    int i;

    q = (Queue *) malloc(sizeof(Queue));
    if (!q) return NULL;
    for (i=0; i<MAXQUEUE; i++) {
        q->item[i] = NULL;
    }
    q->head = q->item;
    q->end = q->item;
    q->destroy_element_function = f1;
    q->copy_element_function = f2;
    q->print_element_function = f3;
    return q;
}
void queue_destroy(Queue *q) {
    if (q) {
        while (q->head != q->end) {
            q->destroy_element_function(*(q->head));
            if (q->head != q->item + MAXQUEUE - 1) q->head = q->head + 1;
            else q->head = q->item;
        }
        free(q);
        q = NULL;
    }
}

Bool queue_isEmpty(const Queue *q) {
    if (q && q->end == q->head) return TRUE;
    return FALSE;
}
Bool queue_isFull(const Queue *q) {
    void **aux = NULL;
    int i = 0;

    if (!q) return FALSE;
    if (q->end == q->item + MAXQUEUE - 1) {
        for (i=0; i<MAXQUEUE; i++) {
            aux[i] = q->copy_element_function(q->item[i]);
        }
    }
    else aux = q->end + 1;
    if (aux == q->head) return TRUE;
    return FALSE;
}

Status queue_insert(Queue *q, const void *pElem) {
    if (!q || !pElem || queue_isFull(q) == TRUE) return ERROR;
    *(q->end) = q->copy_element_function(pElem);
    if (*(q->end) == NULL) return ERROR;
    if (q->end == q->item + MAXQUEUE - 1) q->end = q->item;
    else q->end++;
    return OK;
}

void *queue_extract(Queue *q) {
    void *pElem = NULL;

    if (!q || queue_isEmpty(q) == TRUE) return NULL;
    pElem = q->copy_element_function(*(q->head));
    q->destroy_element_function(*(q->head));
    *(q->head)=NULL;
    if (q->head == q->item + MAXQUEUE - 1) q->head = q->item;
    else q->head++;
    return pElem;
}

int queue_size(const Queue *q) {
    int cuenta = 0, i = 0;

    if (!q || (queue_isEmpty(q) == TRUE)) return -1;
    for (i=0; i<MAXQUEUE; i++) {
        if (q->item[i]) cuenta++;
    }
    return cuenta;
}
int queue_print(FILE *pf, const Queue *q) {
    int cuenta = 0;
    void** queue_item=q->head;

    if (!pf || !q || !queue_item) return -1;

    if (queue_isEmpty(q) == TRUE){
      fprintf(pf, "Queue vacia.\n");
      return 0;
    }

    fprintf(pf, "Cola con %d elementos:\n", queue_size(q));

    while (queue_item!=q->end){
      if (queue_item){
          q->print_element_function(pf, (void*) *queue_item);
          cuenta++;
      }
      if (queue_item == q->item + MAXQUEUE - 1) queue_item = (void**) q->item;
      else queue_item++;
    }

    return cuenta;
}
