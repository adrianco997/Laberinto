/*
 * File: p4_e1.c
 * Authors: Adrian Caballero Orasio, Frederik Mayer
 * Created on 21 de marzo de 2018, 09:28
 */

#include "types.h"
#include "tree.h"
#include "functions.h"
/*

> ./p4_e2 numeros.txt
Numero de nodos: 7
Profundidad: 3
> Introduzca un numero: 5
Numero introducido: 5
El dato 5 se encuentra dentro del Arbol
*/

int main(int argc, char *argv[]) {
    int numero = 0, aux = 0, status = 0;
 	FILE *file = NULL;
    Tree *tree = NULL;

    if (argc < 2) {
        printf("Falta el fichero de datos.\n");
        return -1;
    }

    tree = tree_ini(destroy_intp_function, copy_intp_function, print_intp_function, cmp_intp_function);
    if (!tree) return 1;

    file = fopen(argv[1],"r");
    if (!file) {
        tree_destroy(tree);
        return 1;
    }
 	printf("\nEl contenido de %s es \n", argv[1]);
    while (feof(file) == 0) {
        fscanf(file, "%d" , &aux);
        status = tree_insert(tree, (void *) &aux);
        /*printf("%d-> %2d\n", status, aux);*/
    }
    fclose(file);

    /*status = tree_isEmpty(tree);
    printf("tree_isEmptys:     %2d\n", status);*/
    status = tree_depth(tree);
    printf("Numero de nodos:   %2d\n", status);
    status = tree_numNodes(tree);
    printf("Profundidad:       %2d\n", status);
    /*status = tree_preOrder(stdout, tree);
    printf("tree_preOrder:     %2d\n", status);*/
    /*status = tree_inOrder(stdout, tree);
    printf("tree_inOrder:      %2d\n", status);*/
    /*status = tree_postOrder(stdout, tree);
    printf("tree_postOrder:    %2d\n", status);*/

    printf("\nIntroduzca un numero: ");
    scanf("%d", &numero);
    printf("Numero introducido: %d\n", numero);

    status = tree_find(tree, (void *) &numero);
    if (status == TRUE) printf("El dato %d se encuentra dentro del Arbol\n", numero);
    if (status == FALSE) printf("El dato %d no se encuentra dentro del Arbol\n", numero);
    
    tree_destroy(tree);
	return 0;
}
