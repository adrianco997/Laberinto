package dm2e.laberinto;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RawRes;
import androidx.appcompat.app.AppCompatActivity;

/**
 * @author Adrian Caballeo Orasio
 */
public class MazePlayerDrawActivity extends /*android.app.Activity*/AppCompatActivity {
    private final String TAG = getClass().getName();
    private String laberintoType = "error", nombreJugador = "";
    private Point actual = null, input = null, output = null;
    private MazeView mazeViewer = null;
    private TextView tvContador = null;
    private boolean hasGanado = false;
    private Maze maze = null;
    private int moves = 0;
    private int /*iniWidth, iniHeight,*/ cellsX = 5, cellsY = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mazeplayer_draw);

        this.mazeViewer = findViewById(R.id.MazeView);
        this.mazeViewer.setScaleType(ImageView.ScaleType.MATRIX);

        String[] intent = Utils.getIntentInfo(getIntent());
        this.nombreJugador = intent[0];
        this.laberintoType = intent[1];

        this.tvContador = findViewById(R.id.tvContador);
        Utils.muestraMensaje(this, String.format(getResources().getString(R.string.ordenaLaberinto), this.nombreJugador));

        findViewById(R.id.up).setOnClickListener(new DpadDrawClick());
        findViewById(R.id.down).setOnClickListener(new DpadDrawClick());
        findViewById(R.id.left).setOnClickListener(new DpadDrawClick());
        findViewById(R.id.right).setOnClickListener(new DpadDrawClick());

        iniPlay(this.laberintoType);
    }

    public void iniPlay(String laberintoType) {
        //if (!this.mazeViewer.play(getResourceId(this.laberintoType, "raw"))) onFinish(null);
        if (!play(Utils.getResourceId(this, laberintoType, "raw"))) onFinish(null);
        this.moves = 0;
        this.hasGanado = false;
        this.tvContador.setText(String.format(getResources().getString(R.string.movimientos), this.moves));
    }

    public void restart() {
        //Maze.map_destroy(this.maze);
        this.maze = null;
        this.input = null;
        this.output = null;
        this.actual = null;
        this.hasGanado = false;/*this.width = this.iniWidth;this.height = this.iniHeight;*/
    }

    public boolean play(@RawRes int idFile) {
        restart();
        this.mazeViewer.restart();
        this.maze = new Maze(this);
        if (!this.maze.read(idFile)) {
            Log.e(TAG, "Error en play.read");
            return false;
        }
        if (Utils.checkFile(this, idFile) != -1) {
//            Utils.muestraMensaje(this,getResources().getString(R.string.encontrada));
            if (this.input == null) this.input = maze.getInput();
            if (this.output == null) this.output = maze.getOutput();
            if (this.actual == null) this.actual = this.input;
            Log.i(TAG, "input: " + this.input + ", output: " + this.output + ", actual: " + this.actual);
            printMaze();
            this.mazeViewer.setCellsX(this.cellsX);
            this.mazeViewer.setCellsY(this.cellsY);
            return true;
        } else {
            Utils.muestraMensaje(this, getResources().getString(R.string.noEncontrada));
            return false;
        }
    }


    /***********************************************************************************************/
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_mazeplayer_text, menu);
        Utils.onCreateOptionsMenuItems(this, menu, cellsX, cellsY);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.musica: {
                item.setIcon(Utils.musicaPlayStop(this, false));
                return true;
            }
            case R.id.x_size: {
                item.setTitle(getString(R.string.x_size, mazeViewer.addCellsX()));
                printMaze();
                return true;
            }
            case R.id.y_size: {
                item.setTitle(getString(R.string.y_size, mazeViewer.addCellsY()));
                printMaze();
                return true;
            }
            case R.id.restart: {
                Utils.muestraMensaje(this, "restart");
                iniPlay(this.laberintoType);
                return true;
            }
            case R.id.help: {
                //Utils.muestraMensaje(this,"help, por hacer");
                final View v = findViewById(R.id.action_settings);/*item.getActionView()*/
                openPopup(v, R.id.help);
                return true;
            }
            default: {
                return super.onOptionsItemSelected(item);
            }
        }
    }

    public void openPopup(View view) {
        Utils.openPopup(this, view, view.getId());
    }

    public void openPopup(View view, /*@IdRes*/ int idPopup) {
        Utils.openPopup(this, view, idPopup);
    }

    /***********************************************************************************************/
    //public void main(int[] args) { if (args.length == 0) { main(new int[]{R.raw.m1});/*main(new int[] { R.raw.m2. });*//*main(new int[] { R.raw.m3. });*//*main(new int[] { R.raw.m4. });*/return; }/*ejsOld(args[0], 0);*/play(args[0]); }
    //public void ejsOld(int mfile, int i) { String texto = "SALIDA ENCONTRADA, longitud del camino con %s y estrategia %s, %s, %s, %s: %d unidades.\n", tipo = "algoritmo recursivo";System.out.println("-->Recursivo:\n");MazeSolver ms = new MazeSolver();int pathlength = ms.recursiveSolver(this, mfile, strat1, true);if (pathlength != -1) { System.out.printf(texto, tipo, strat[i][0], strat[i][1], strat[i][2], strat[i][3], pathlength); } else { System.err.println("SALIDA NO ENCONTRADA."); }ms.runSolver(this, mfile, strat); }
    ///**llama a stackSolver, queueSolver y recursiveSolver con una matriz de movimientos*/public void runSolver(Context contexto, int mfile, Movements[][] strat) { for (Movements[] movements : strat) { if (movements.length != 4) { System.err.println("Numero de movimientos incorrecto.");return; }System.out.printf("ESTRATEGIA %s, %s, %s, %s\n", movements[0], movements[1], movements[2], movements[3]);struct(contexto, "pila", mfile, movements, true, 2);struct(contexto, "cola", mfile, movements, true, 2);struct(contexto, "algoritmo recursivo", mfile, movements, true, 3); } }
    //public void struct(Context contexto, String solver, int mfile, Movements[] strat, boolean compare, int type) { String texto = "SALIDA ENCONTRADA, longitud del camino con %s y estrategia %s, %s, %s, %s: %d unidades.\n";System.out.println(Utils.formatR("Con " + solver + ":", '-', 108));int pathlength = -1;if (type == 1) { pathlength = stackSolver(contexto, mfile, strat); } else if (type == 2) { pathlength = queueSolver(contexto, mfile, strat); } else if (type == 3) { pathlength = recursiveSolver(contexto, mfile, strat, compare); } //else { }if (pathlength != -1) { System.out.printf(texto, solver, strat[0], strat[1], strat[2], strat[3], pathlength); } else { System.err.println("SALIDA NO ENCONTRADA."); }System.out.println(Utils.formatL("", '-', 108)); }
    ///**resolve un mapa usando una pila.*/public int stackSolver(Context contexto, int mfile, Movements[] strat) { Maze maze = new Maze();if (strat.length != 4) { return -1; }if (!maze.read(contexto, mfile)) { System.err.println("Error en recursiveSolver.");return -1; }System.out.println("Maze:\n" + maze.toString());System.out.println("Input:\n" + maze.getInput().print());int pathlength;pathlength = maze.deepSearchStack(maze.getInput(), strat);System.out.println(((pathlength != -1) ? "Output found, length of path: " + pathlength : "No path found."));System.out.println(maze.toString());System.out.printf("Final maze: %s%n", maze.pathPaint(maze.getOutput()));return pathlength; }
    ///**resolve un mapa usando una cola.*/public int queueSolver(Context contexto, int mfile, Movements[] strat) { Maze maze = new Maze();if (strat.length != 4) { return -1; }if (!maze.read(contexto, mfile)) { System.err.println("Error en recursiveSolver.");return -1; }System.out.println("Maze:\n" + maze.toString());System.out.println("Input:\n" + maze.getInput().print());int pathlength;pathlength = maze.breadthSearchQueue(maze.getInput(), strat);System.out.println(((pathlength != -1) ? "Output found, length of path: " + pathlength : "No path found."));System.out.println(maze.toString());System.out.printf("Final maze: %s%n", maze.pathPaint(maze.getOutput()));return pathlength; }
    ///**resolve un mapa usando un algoritmo recursivo.*/public int recursiveSolver(Context contexto, int mfile, Movements[] strat, boolean compare) { Maze maze = new Maze();if (strat.length != 4) { return -1; }if (!maze.read(contexto, mfile)) { System.err.println("Error en recursiveSolver.");return -1; }System.out.println("Maze:\n" + maze.toString() + "\n" + "Input:\n" + maze.getInput().print());int pathlength;Point out = maze.deepSearchRec(maze.getInput(), strat, compare);if (out != null) { pathlength = maze.pathPaint(out);System.out.printf("Output is in point: %s%n", out.toString()); } else { pathlength = -1; }System.out.println(((pathlength != -1) ? "Output found, length of path: " + pathlength : "No path found."));System.out.println(maze.toString());System.out.printf("Final maze: %s%n", maze.pathPaint(maze.getOutput()));return pathlength; }

    private class DpadDrawClick implements View.OnClickListener {
        public void onClick(View v) {
            if (!hasGanado && actual != null) {
                Point neighbor = Utils.getNeighbor(v, maze, actual);
                if (neighbor != null && !neighbor.isErrorChar() && !neighbor.isBarrier()) {
                    actual = neighbor;
                    moves++;
                    tvContador.setText(String.format(getResources().getString(R.string.movimientos), moves));
                }
                printMaze();
                if (actual.equals(output)) {
                    tvContador.setText(String.format(getResources().getString(R.string.movimientos), moves));
                    Utils.muestraMensaje(getBaseContext(), String.format(getResources().getString(R.string.ganado), moves));
                    onGanar();
                }
            } else onFinish(v);
        }
    }

    public void printMaze() {
        this.mazeViewer.setActual(actual);
        this.mazeViewer.setMaze(this.maze);
        this.mazeViewer.invalidate();
        //this.mazeViewer.drawMaze( this.maze, this.actual);
    }

    /****************************************************************/
    protected void onGanar() {
        long id = 0;
        this.hasGanado = true;
        //onPause();

        try {
            SQLiteHelper_Ranking db = SQLiteHelper_Ranking.getInstance(this);
            Ranking ranking = new Ranking(this.nombreJugador, this.laberintoType, this.moves);
            id = db.addOrUpdateRanking(ranking);/*db.addRanking(ranking);*/
//            actualizarBD();
        } catch (Exception e) {
            Log.e(TAG, "(" + id + ")" + e);
        }
//        actualizarBD();
    }

    //    protected void actualizarBD() { String txt = "Rankings:\n";try { SQLiteHelper_Ranking db = SQLiteHelper_Ranking.getInstance(this);List<Ranking> ranking = db.getAllRankings();for (Ranking r : ranking) { txt = String.format("%s%s\n", txt, r.toString(this)); }((TextView) findViewById(R.id.tvGanardores)).setText(txt); } catch (Exception e) { Utils.muestraMensaje(this,getResources().getString(R.string.errorGanardores)); } }
    public void onFinish(View v) {
        Musica.stop();
        Musica.release();
        /*setResult(RESULT_OK, new Intent().putExtra("respuesta", String.format(getResources().getString(R.string.ganado), movimientos)));*/
        finish();
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
}
