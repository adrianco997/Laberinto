package dm2e.laberinto;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SubMenu;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.RawRes;
import androidx.appcompat.app.AppCompatActivity;

/**
 * @author Adrian Caballeo Orasio
 */
public class MazePlayerTextActivity extends AppCompatActivity {
    private final String TAG = getClass().getName();
    private String laberintoType = "error", nombreJugador = "";
    private Point actual = null, input = null, output = null;
    private TextView mazeViewer = null;
    private TextView tvContador = null;
    private boolean hasGanado = false;
    private Maze maze = null;
    private int moves = 0;
    private int /*iniWidth, iniHeight,*/ cellsX = 5, cellsY = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mazeplayer_text);

        this.mazeViewer = findViewById(R.id.maze_text);

        String[] intent = Utils.getIntentInfo(getIntent());
        this.nombreJugador = intent[0];
        this.laberintoType = intent[1];

        this.tvContador = findViewById(R.id.tvContador);
        Utils.muestraMensaje(this,String.format(getResources().getString(R.string.ordenaLaberinto), this.nombreJugador));

        findViewById(R.id.up).setOnClickListener(new DpadTextClick());
        findViewById(R.id.down).setOnClickListener(new DpadTextClick());
        findViewById(R.id.left).setOnClickListener(new DpadTextClick());
        findViewById(R.id.right).setOnClickListener(new DpadTextClick());

        iniPlay(this.laberintoType);
    }

    public void iniPlay(String laberintoType) {
        if (!play(Utils.getResourceId(this, laberintoType, "raw"))) onFinish(null);
        this.moves = 0;
        this.hasGanado = false;
        this.tvContador.setText(String.format(getResources().getString(R.string.movimientos), this.moves));
    }

    public void restart() {
        //Maze.map_destroy(this.maze);
        this.maze = null;
        this.input = null;
        this.output = null;
        this.actual = null;
        this.hasGanado = false;
    }

    public boolean play(@RawRes int idFile) {
        restart();
        this.maze = new Maze(this);
        if (!this.maze.read(idFile)) {
            Log.e(TAG, "Error en play.read");
            return false;
        }
        if (Utils.checkFile(this, idFile) != -1) {
//            Utils.muestraMensaje(this,getResources().getString(R.string.encontrada));
            if (this.input == null) this.input = maze.getInput();
            if (this.output == null) this.output = maze.getOutput();
            if (this.actual == null) this.actual = this.input;
            Log.i(TAG, "input: " + this.input + ", output: " + this.output + ", actual: " + this.actual);
            //if (maze.getNcols() < 19) cellsX = maze.getNcols();
            //if (maze.getNrows() < 8) cellsY = maze.getNrows();
            printMaze();
            return true;
        } else {
            Utils.muestraMensaje(this, getResources().getString(R.string.noEncontrada));
            return false;
        }
    }


    /***********************************************************************************************/
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_mazeplayer_text, menu);
        Utils.onCreateOptionsMenuItems(this, menu, cellsX, cellsY);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.musica: {
                item.setIcon(Utils.musicaPlayStop(this, false));
                return true;
            }
            case R.id.x_size: {
                if (this.cellsX < 10) this.cellsX += 1;
                else this.cellsX = 3;
                printMaze();
                item.setTitle(getString(R.string.x_size, cellsX));
                return true;
            }
            case R.id.y_size: {
                if (cellsY < 10) this.cellsY += 1;
                else this.cellsY = 3;
                printMaze();
                item.setTitle(getString(R.string.y_size, cellsY));
                return true;
            }
            case R.id.restart: {
                Utils.muestraMensaje(this, "restart");
                iniPlay(this.laberintoType);
                return true;
            }
            case R.id.help: {
                final View v = findViewById(R.id.action_settings);
                openPopup(v, R.id.help);
                return true;
            }
            default: {
                return super.onOptionsItemSelected(item);
            }
        }
    }

    public void openPopup(View view) {
        Utils.openPopup(this, view, view.getId());
    }

    public void openPopup(View view, /*@IdRes*/ int idPopup) {
        Utils.openPopup(this, view, idPopup);
    }

    /***********************************************************************************************/
    //public void main(int[] args) { if (args.length == 0) { main(new int[]{R.raw.m1});/*main(new int[] { R.raw.m2. });*//*main(new int[] { R.raw.m3. });*//*main(new int[] { R.raw.m4. });*/return; }/*ejsOld(args[0], 0);*/play(args[0]); }
    //public void ejsOld(int mfile, int i) { String texto = "SALIDA ENCONTRADA, longitud del camino con %s y estrategia %s, %s, %s, %s: %d unidades.\n", tipo = "algoritmo recursivo";System.out.println("-->Recursivo:\n");MazeSolver ms = new MazeSolver();int pathlength = ms.recursiveSolver(this, mfile, strat1, true);if (pathlength != -1) { System.out.printf(texto, tipo, strat[i][0], strat[i][1], strat[i][2], strat[i][3], pathlength); } else { System.err.println("SALIDA NO ENCONTRADA."); }ms.runSolver(this, mfile, strat); }
    ///**llama a stackSolver, queueSolver y recursiveSolver con una matriz de movimientos*/public void runSolver(Context contexto, int mfile, Movements[][] strat) { for (Movements[] movements : strat) { if (movements.length != 4) { System.err.println("Numero de movimientos incorrecto.");return; }System.out.printf("ESTRATEGIA %s, %s, %s, %s\n", movements[0], movements[1], movements[2], movements[3]);struct(contexto, "pila", mfile, movements, true, 2);struct(contexto, "cola", mfile, movements, true, 2);struct(contexto, "algoritmo recursivo", mfile, movements, true, 3); } }
    //public void struct(Context contexto, String solver, int mfile, Movements[] strat, boolean compare, int type) { String texto = "SALIDA ENCONTRADA, longitud del camino con %s y estrategia %s, %s, %s, %s: %d unidades.\n";System.out.println(Utils.formatR("Con " + solver + ":", '-', 108));int pathlength = -1;if (type == 1) { pathlength = stackSolver(contexto, mfile, strat); } else if (type == 2) { pathlength = queueSolver(contexto, mfile, strat); } else if (type == 3) { pathlength = recursiveSolver(contexto, mfile, strat, compare); } //else { }if (pathlength != -1) { System.out.printf(texto, solver, strat[0], strat[1], strat[2], strat[3], pathlength); } else { System.err.println("SALIDA NO ENCONTRADA."); }System.out.println(Utils.formatL("", '-', 108)); }
    ///**resolve un mapa usando una pila.*/public int stackSolver(Context contexto, int mfile, Movements[] strat) { Maze maze = new Maze();if (strat.length != 4) { return -1; }if (!maze.read(contexto, mfile)) { System.err.println("Error en recursiveSolver.");return -1; }System.out.println("Maze:\n" + maze.toString());System.out.println("Input:\n" + maze.getInput().print());int pathlength;pathlength = maze.deepSearchStack(maze.getInput(), strat);System.out.println(((pathlength != -1) ? "Output found, length of path: " + pathlength : "No path found."));System.out.println(maze.toString());System.out.printf("Final maze: %s%n", maze.pathPaint(maze.getOutput()));return pathlength; }
    ///**resolve un mapa usando una cola.*/public int queueSolver(Context contexto, int mfile, Movements[] strat) { Maze maze = new Maze();if (strat.length != 4) { return -1; }if (!maze.read(contexto, mfile)) { System.err.println("Error en recursiveSolver.");return -1; }System.out.println("Maze:\n" + maze.toString());System.out.println("Input:\n" + maze.getInput().print());int pathlength;pathlength = maze.breadthSearchQueue(maze.getInput(), strat);System.out.println(((pathlength != -1) ? "Output found, length of path: " + pathlength : "No path found."));System.out.println(maze.toString());System.out.printf("Final maze: %s%n", maze.pathPaint(maze.getOutput()));return pathlength; }
    ///**resolve un mapa usando un algoritmo recursivo.*/public int recursiveSolver(Context contexto, int mfile, Movements[] strat, boolean compare) { Maze maze = new Maze();if (strat.length != 4) { return -1; }if (!maze.read(contexto, mfile)) { System.err.println("Error en recursiveSolver.");return -1; }System.out.println("Maze:\n" + maze.toString() + "\n" + "Input:\n" + maze.getInput().print());int pathlength;Point out = maze.deepSearchRec(maze.getInput(), strat, compare);if (out != null) { pathlength = maze.pathPaint(out);System.out.printf("Output is in point: %s%n", out.toString()); } else { pathlength = -1; }System.out.println(((pathlength != -1) ? "Output found, length of path: " + pathlength : "No path found."));System.out.println(maze.toString());System.out.printf("Final maze: %s%n", maze.pathPaint(maze.getOutput()));return pathlength; }

    private class DpadTextClick implements View.OnClickListener {
        public void onClick(View v) {
            if (!hasGanado && actual != null) {
                Point neighbor = Utils.getNeighbor(v, maze, actual);
                if (neighbor != null && !neighbor.isErrorChar() && !neighbor.isBarrier()) {
                    actual = neighbor;
                    moves++;
                    tvContador.setText(String.format(getResources().getString(R.string.movimientos), moves));
                }
                printMaze();
                if (actual.equals(output)) {
                    tvContador.setText(String.format(getResources().getString(R.string.movimientos), moves));
                    Utils.muestraMensaje(getBaseContext(), String.format(getResources().getString(R.string.ganado), moves));
                    onGanar();
                }
            } else onFinish(v);
        }
    }

    // TODO: conseguir tamaño de mazeText al inicializar, comparar tamaño y tamaño de letra para asegurar que todo el printMaze() se muestra, cambiar tamaño de letra si no
    //public void printMaze0() { this.mazeText.setText(R.string.laberinto_text_1); }
    private int width2, height2;

    public void printMaze() {
//        final LinearLayout layout = (LinearLayout) findViewById(R.id.maze_text).getParent();//this.mazeText.getParent();//this.mazeText;
//        ViewTreeObserver vto = layout.getViewTreeObserver();
//        vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {@Override public void onGlobalLayout() { if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) { layout.getViewTreeObserver().removeGlobalOnLayoutListener(this); } else { layout.getViewTreeObserver().removeOnGlobalLayoutListener(this); }width2 = layout.getMeasuredWidth();height2 = layout.getMeasuredHeight(); }});/**/
        int width = this.mazeViewer.getWidth(), max_width = this.mazeViewer.getMaxWidth(), min_width = this.mazeViewer.getMinWidth(), measured_width = this.mazeViewer.getMeasuredWidth();
        int height = this.mazeViewer.getHeight(), max_height = this.mazeViewer.getMaxHeight(), min_height = this.mazeViewer.getMinHeight(), measured_height = this.mazeViewer.getMeasuredHeight();
        float textSize = this.mazeViewer.getTextSize(), paintTextSize = this.mazeViewer.getPaint().getTextSize();
        StringBuilder txt = new StringBuilder();
        for (int i = 0; i < 8; i++) txt.append(Utils.formatC("" + i, '$', 25)).append("\n");
        this.mazeViewer.setText(txt.toString());
        int size[] = getViewSize((View) findViewById(R.id.maze_text).getParent());//this.mazeText.getParent();//this.mazeText;
        System.out.printf("Size: [%s][%s]\tMax: [%s][%s]\tMin: [%s][%s]\tMeasured: [%s][%s]\n", height, width, max_height, max_width, min_height, min_width, measured_height, measured_width);
        System.out.printf("Text y Paint Size: [%s][%s]\n", textSize, paintTextSize);
        System.out.printf("getViewSize: [%s][%s]\n.", size[0], size[1]);
        System.out.printf("Size2: [%s][%s]\n.", size[0], size[1]);
        //+   [  41][  18]  [20sp=30.0, max=25,8]
        //m1  [ 251][ 126]  [20sp=30.0, max=25,8]
        //m2  [ 253][ 126]  [20sp=30.0, max=25,8]
        //m3  [ 297][1476]  [20sp=30.0, max=25,8]
        //max [ 297][ 450]  [20sp=30.0, max=25,8]
//        this.maze.setScreenSize(max_width, max_height);//this.maze.setScreenSize(min_width, min_height);//this.maze.setScreenSize(measured_width, measured_height);
        this.maze.setScreenSize(width, height);
        this.mazeViewer.setText(this.maze.printMaze(this.actual, this.cellsX, this.cellsY));/*this.mazeText.setText(this.maze.toString());*/
        //vacio->m1, 20sp
//        I/System.out: Size.V: [800][480] [0][-2147483168] [ 41][  0]//        I/System.out: Size: [  0][  0] [  0][  0]
//        I/System.out: Size.V: [800][480] [0][-2147483168] [251][126]//        I/System.out: Size: [297][450] [297][450]
        //vacio->max, 20sp
//        I/System.out: Size.V: [800][480] [0][-2147483168] [ 41][  0]//        I/System.out: Size: [  0][  0] [  0][  0]
//        I/System.out: Size.V: [800][480] [0][-2147483168] [323][468]//        I/System.out: Size: [297][450] [297][450]
    }

    public static int[] getViewSize(View view) {
        WindowManager wm = (WindowManager) view.getContext().getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        int deviceWidth;
        int deviceHeight;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            android.graphics.Point size = new android.graphics.Point();
            display.getSize(size);
            deviceWidth = size.x;
            deviceHeight = size.y;
        } else {
            deviceWidth = display.getWidth();
            deviceHeight = display.getHeight();
        }
//        I/System.out: Size.1: [800][480]
//        I/System.out: Size.2: [0][-2147483168]
//        I/System.out: Size.3: [251][108] --> [251][126]m1
        int widthMeasureSpec = View.MeasureSpec.makeMeasureSpec(deviceWidth, View.MeasureSpec.AT_MOST);
        int heightMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        view.measure(widthMeasureSpec, heightMeasureSpec);
        System.out.printf("Size.V: [%s][%s] [%s][%s] [%s][%s]\n", deviceHeight, deviceWidth, heightMeasureSpec, widthMeasureSpec, view.getMeasuredHeight(), view.getMeasuredWidth());
        return new int[]{view.getMeasuredHeight(), view.getMeasuredWidth()};
    }

    /****************************************************************/
    protected void onGanar() {
        long id = 0;
        this.hasGanado = true;
        //onPause();
        try {
            SQLiteHelper_Ranking db = SQLiteHelper_Ranking.getInstance(this);
            Ranking ranking = new Ranking(this.nombreJugador, this.laberintoType, this.moves);
            id = db.addOrUpdateRanking(ranking);/*db.addRanking(ranking);*/
//            actualizarBD();
        } catch (Exception e) {
            Log.e(TAG, "(" + id + ")" + e);
        }
//        actualizarBD();
    }

    //    protected void actualizarBD() { String txt = "Rankings:\n";try { SQLiteHelper_Ranking db = SQLiteHelper_Ranking.getInstance(this);List<Ranking> ranking = db.getAllRankings();for (Ranking r : ranking) { txt = String.format("%s%s\n", txt, r.toString(this)); }((TextView) findViewById(R.id.tvGanardores)).setText(txt); } catch (Exception e) { Utils.muestraMensaje(this,getResources().getString(R.string.errorGanardores)); } }
    public void onFinish(View v) {
        Musica.stop();
        Musica.release();
        /*setResult(RESULT_OK, new Intent().putExtra("respuesta", String.format(getResources().getString(R.string.ganado), movimientos)));*/
        finish();
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
}

